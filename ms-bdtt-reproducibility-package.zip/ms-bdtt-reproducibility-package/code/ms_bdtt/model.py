"""MS-BDTT — attention-weighted adversarial transfer network (Section 3.5).

Components:
    GradientReverseLayer  gradient reversal layer (GRL) with lambda ramp
    ResBlock / ResCNN1D  six-block 1-D residual feature extractor
    DomainDiscriminator  domain classifier behind the GRL
    DiagnosticClassifier label classifier on the 512-d feature vector

The feature extractor is shared by MS-BDTT and all baselines (Section 4.3).
"""

from __future__ import annotations

import torch
import torch.nn as nn


class GradientReverseLayer(torch.autograd.Function):
    """Identity forward, -lambda * gradient backward (GRL, [19, 21])."""

    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.lambd, None


def grad_reverse(x: torch.Tensor, lambd: float = 1.0) -> torch.Tensor:
    return GradientReverseLayer.apply(x, lambd)


class ResBlock(nn.Module):
    """Two conv + BN + ReLU layers with a skip connection (1x1 conv on channel change)."""

    def __init__(self, in_ch: int, out_ch: int, kernel_size: int = 15):
        super().__init__()
        pad = kernel_size // 2
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel_size, padding=pad)
        self.bn1 = nn.BatchNorm1d(out_ch)
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel_size, padding=pad)
        self.bn2 = nn.BatchNorm1d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        self.skip = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.relu(self.bn1(self.conv1(x)))
        h = self.bn2(self.conv2(h))
        return self.relu(h + self.skip(x))


class ResCNN1D(nn.Module):
    """1-D residual CNN feature extractor (Section 3.5.1, Figure 4 top).

    Stem: 64-channel convolution; six residual blocks with channel widths
    [64, 128, 256, 256, 512, 512]; global average pooling -> 512-d feature z.
    """

    def __init__(self, in_ch: int = 1, channels=(64, 128, 256, 256, 512, 512)):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv1d(in_ch, channels[0], 31, padding=15),
            nn.BatchNorm1d(channels[0]),
            nn.ReLU(inplace=True),
        )
        blocks = []
        prev = channels[0]
        for c in channels:
            blocks.append(ResBlock(prev, c))
            prev = c
        self.blocks = nn.Sequential(*blocks)
        self.out_dim = channels[-1]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (B, 1, L)
        h = self.stem(x)
        h = self.blocks(h)
        return h.mean(dim=-1)  # global average pooling -> (B, 512)


class DomainDiscriminator(nn.Module):
    """Two-layer domain classifier behind the GRL (Section 3.5)."""

    def __init__(self, in_dim: int = 512, hidden: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(inplace=True),
            nn.Linear(hidden, hidden), nn.ReLU(inplace=True),
            nn.Linear(hidden, 1),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)


class DiagnosticClassifier(nn.Module):
    """Linear label classifier on the 512-d feature vector."""

    def __init__(self, in_dim: int = 512, n_classes: int = 5):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 256), nn.ReLU(inplace=True),
            nn.Linear(256, n_classes),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)
