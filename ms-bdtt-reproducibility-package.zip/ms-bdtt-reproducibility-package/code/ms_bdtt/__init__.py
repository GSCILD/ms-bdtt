"""MS-BDTT package: model, attention, particle filter, losses, demand map."""
