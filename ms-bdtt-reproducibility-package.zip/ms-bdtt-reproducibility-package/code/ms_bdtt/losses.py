"""Loss functions of the joint optimisation objective (Section 3.5.2).

    L_total = L_diag + lambda * L_adv + mu * L_phy                        (10)

    L_phy = (1/n) sum_t [ (E_t - E_sim,t)^2 / E_ref^2
                          + ( f_BPFO,sim / f_r - f_BPFO,geom / f_r )^2 ]  (10a)

The first term of L_phy penalises the squared relative deviation of the energy
carried by the fault characteristic band of each bridge sample from the energy
of its clean simulator counterpart, normalised by the reference energy; the
second term penalises the relative deviation of the simulated ball-pass
outer-race frequency from its geometric value. Both terms are dimensionless, so
L_phy is dimensionless and its weight mu is a pure number.

Weights: lambda = 0.5 (ramped from 0 over the first 20 epochs), mu = 0.1,
both selected by grid search on the S1 validation split (Appendix D).
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F


def diagnostic_loss(logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    """L_diag: cross-entropy on the labelled bridge samples."""
    return F.cross_entropy(logits, labels)


def adversarial_loss(domain_logits: torch.Tensor, domains: torch.Tensor) -> torch.Tensor:
    """L_adv: domain classification loss computed through gradient reversal [19, 21]."""
    return F.cross_entropy(domain_logits, domains)


def band_energy(x: torch.Tensor, fs: float, lo: float, hi: float) -> torch.Tensor:
    """Energy of the [lo, hi] band of a batch of 1-D signals (rFFT based)."""
    X = torch.fft.rfft(x, dim=-1)
    f = torch.fft.rfftfreq(x.shape[-1], d=1.0 / fs, device=x.device)
    mask = (f >= lo) & (f < hi)
    return (X.abs() ** 2)[..., mask].sum(dim=-1)


def physical_consistency_loss(bridge_signals: torch.Tensor,
                              clean_signals: torch.Tensor,
                              fs: float,
                              bpfo_band: tuple[float, float],
                              bpfo_ratio_sim: torch.Tensor,
                              bpfo_ratio_geom: torch.Tensor,
                              e_ref: torch.Tensor) -> torch.Tensor:
    """L_phy of Eq. (10a).

    Parameters
    ----------
    bridge_signals : (n, L) noisy bridge samples (after the sensor model)
    clean_signals  : (n, L) their clean simulator counterparts
    fs             : sampling frequency (Hz)
    bpfo_band      : (lo, hi) fault characteristic band of the BPFO component
    bpfo_ratio_sim : simulated BPFO/running-speed ratio (per sample or scalar)
    bpfo_ratio_geom: geometric BPFO/running-speed ratio (per sample or scalar)
    e_ref          : reference energy for normalisation (per sample or scalar)
    """
    e_bridge = band_energy(bridge_signals, fs, *bpfo_band)
    e_clean = band_energy(clean_signals, fs, *bpfo_band)
    term1 = ((e_bridge - e_clean) / e_ref) ** 2
    term2 = (bpfo_ratio_sim - bpfo_ratio_geom) ** 2
    return (term1 + term2).mean()


def lambda_ramp(epoch: int, total_epochs: int, ramp_epochs: int = 20,
                lambda_final: float = 0.5) -> float:
    """Ramp the adversarial weight from 0 to lambda over the first `ramp_epochs`."""
    if ramp_epochs <= 0:
        return lambda_final
    frac = min(1.0, (epoch + 1) / ramp_epochs)
    return lambda_final * frac


def total_loss(l_diag: torch.Tensor, l_adv: torch.Tensor, l_phy: torch.Tensor,
               lambd: float = 0.5, mu: float = 0.1) -> torch.Tensor:
    """L_total of Eq. (10)."""
    return l_diag + lambd * l_adv + mu * l_phy
