"""Train and evaluate MS-BDTT for one scenario (Sections 3.1-3.6, 4.4).

Pipeline:
    1. Seed everything (42): torch, cuda, numpy.
    2. Build the continuous-domain bridge with MarineSim over the K = 9
       interpolation nodes (Eq. 2); compute the composite demand map (Eq. 4)
       from band-energy features and a reference sensitivity classifier, and
       apply the demand-guided allocation (Eq. 5).
    3. Calibrate the digital twin with the Bayesian particle filter (Algorithm 1)
       against unlabelled normal-condition target samples only.
    4. Train the attention-weighted adversarial network (Eqs. 9, 10) with the
       shared 1-D ResCNN backbone, Adam (lr 1e-3, cosine annealing), batch 64,
       lambda ramped from 0 to 0.5 over the first 20 epochs. The diagnostic loss
       is computed on the labelled bridge samples and weighted by the mean
       attention they receive from the target queries (the target-oriented
       training distribution of Section 3.6); the physical consistency loss
       (Eq. 10a) compares each bridge sample with its clean counterpart.
    5. Evaluate OA and per-class F1 on the disjoint target test set; write the
       run-level predictions and the scenario metrics JSON.

All hyperparameters come from the configuration file (configs/ms_bdtt_trained_config.yaml);
values are the ones selected on the S1 validation split (Appendix D).

Usage:
    python train.py --scenario S5 --config ../../configs/ms_bdtt_trained_config.yaml \
        --cache ../../cache --out ../../results/run_level_predictions
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np
import torch
import yaml

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from ms_bdtt.model import ResCNN1D, DomainDiscriminator, DiagnosticClassifier, grad_reverse
from ms_bdtt.attention import SampleAttention
from ms_bdtt.losses import (diagnostic_loss, adversarial_loss, lambda_ramp,
                            physical_consistency_loss, total_loss, band_energy)
from ms_bdtt.demand_map import allocate, build_demand_scores
from ms_bdtt.particle_filter import (BayesianCalibrator, ParticleFilterConfig,
                                     band_limited_spectrum)

from marinesim.generate_spfd import generate_bridge
from marinesim.rotordynamics import simulate_signal


def seed_everything(seed: int = 42) -> None:
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_cache(cache_dir: str, dataset: str, condition: str | None, partition: str):
    """Load one cache NPZ for (dataset, condition, partition)."""
    pattern = os.path.join(cache_dir, f"{dataset}_{condition or '*'}_{partition}.npz")
    matches = sorted(glob.glob(pattern))
    assert matches, f"no cache file for {dataset}/{condition}/{partition} in {cache_dir}"
    data = np.load(matches[0])
    return data["windows"], data["labels"], data["records"]


def band_energy_features(windows: np.ndarray, fs: float) -> np.ndarray:
    """Band-energy feature vector per window (demand-map and sensitivity input)."""
    feats = []
    for w in windows:
        X = np.abs(np.fft.rfft(w)) ** 2
        f = np.fft.rfftfreq(len(w), d=1.0 / fs)
        lo, mid, hi = X[(f < 500)].sum(), X[(f >= 500) & (f < 2000)].sum(), X[(f >= 2000)].sum()
        tot = X.sum() + 1e-12
        feats.append([lo / tot, mid / tot, hi / tot])
    return np.asarray(feats)


class SensitivityReference:
    """Tiny softmax regression used as the reference classifier of Section 3.3."""

    def __init__(self, n_features: int, n_classes: int, lr: float = 0.5, epochs: int = 200):
        self.W = np.zeros((n_features, n_classes))
        self.b = np.zeros(n_classes)
        self.lr, self.epochs = lr, epochs

    def fit(self, X: np.ndarray, y: np.ndarray) -> "SensitivityReference":
        classes = sorted(set(y.tolist()))
        self.classes = classes
        yidx = np.array([classes.index(v) for v in y])
        Y = np.eye(len(classes))[yidx]
        for _ in range(self.epochs):
            logits = X @ self.W + self.b
            p = np.exp(logits - logits.max(axis=1, keepdims=True))
            p /= p.sum(axis=1, keepdims=True)
            grad = (p - Y) / len(X)
            self.W -= self.lr * (X.T @ grad + 1e-3 * self.W)
            self.b -= self.lr * grad.sum(axis=0)
        return self

    def __call__(self, X: np.ndarray) -> np.ndarray:
        logits = X @ self.W + self.b
        return logits.argmax(axis=1)


def build_bridge(simulator_cfg: dict, spfd_cfg: dict, n_nodes: int,
                 samples_per_node: int, seed: int, alpha: float = 0.6,
                 target_windows: np.ndarray | None = None):
    """Bridge samples with the demand-guided allocation (Eqs. 2, 4, 5)."""
    bridge = generate_bridge(simulator_cfg, spfd_cfg, n_nodes=n_nodes,
                             samples_per_node=samples_per_node, seed=seed)
    fs = float(spfd_cfg["output"]["fs_hz"])
    node_features = [band_energy_features(bridge[k]["windows"][:128], fs) for k in range(n_nodes)]
    if target_windows is None:
        target_windows = bridge[n_nodes - 1]["windows"][:128]
    target_features = band_energy_features(target_windows, fs)

    # fault-sensitivity gradient per node: finite difference of the reference
    # classifier accuracy across the severity-ordered bridge windows
    sensitivity = []
    for k in range(n_nodes):
        labels = bridge[k]["labels"]
        groups = sorted(set(labels.tolist()))
        if len(groups) < 2:
            sensitivity.append(0.0)
            continue
        ref = SensitivityReference(n_features=3, n_classes=len(groups)).fit(
            node_features[k], labels)
        # accuracy at the two severity extremes of the node's fault groups
        accs = []
        for g in (groups[0], groups[-1]):
            m = labels == g
            if m.sum() == 0:
                accs.append(0.0)
            else:
                accs.append(float((ref(node_features[k][m]) == labels[m]).mean()))
        sensitivity.append(abs(accs[-1] - accs[0]))

    demand = build_demand_scores(node_features, target_features, sensitivity, alpha=alpha)
    total = samples_per_node * n_nodes
    alloc = allocate(demand, total, min_per_node=5)
    return bridge, alloc, demand


def calibrate(simulator_cfg: dict, spfd_cfg: dict, normal_windows: np.ndarray,
              fs: float, seed: int = 42) -> np.ndarray:
    """Bayesian particle-filter calibration (Algorithm 1) on unlabelled normals."""
    rng = np.random.default_rng(seed)
    bands = [(0.0, 500.0), (500.0, 2000.0), (2000.0, 8000.0)]
    phi_meas = [band_limited_spectrum(w, fs, bands) for w in normal_windows[:32]]
    calibrator = BayesianCalibrator(ParticleFilterConfig())

    def simulate_fn(theta, t):
        op = {"speed_rpm": 500.0, "load_mcr": 65.0,
              "shaft_alignment_offset_mm": 0.0, "gear_mesh_hz": 500.0 / 60.0 * 37.0,
              "imbalance_mass_g": 0.5, "imbalance_eccentricity_m": 1e-4,
              "k_calibration": theta[0], "c_calibration": theta[1]}
        sig = simulate_signal(simulator_cfg, op, None, rng, fs=fs)
        return band_limited_spectrum(sig[:2048], fs, bands)

    out = calibrator.run(simulate_fn, phi_meas, rng=rng, update_s=False)
    return out["theta_hat"]


def main():
    ap = argparse.ArgumentParser(description="Train and evaluate MS-BDTT")
    ap.add_argument("--scenario", required=True, choices=["S1", "S2", "S3", "S4", "S5"])
    ap.add_argument("--config", required=True, help="trained model configuration YAML")
    ap.add_argument("--simulator-config", default=None)
    ap.add_argument("--cache", required=True, help="windowed cache directory")
    ap.add_argument("--out", required=True, help="output directory")
    ap.add_argument("--epochs", type=int, default=None)
    args = ap.parse_args()

    seed_everything(42)
    with open(args.config, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    here = os.path.dirname(os.path.abspath(__file__))
    sim_cfg_path = args.simulator_config or os.path.join(
        here, "..", "marinesim", "configs", "simulator_config.yaml")
    with open(sim_cfg_path, encoding="utf-8") as f:
        simulator_cfg = yaml.safe_load(f)
    with open(os.path.join(here, "..", "marinesim", "configs", "spfd_config.yaml"),
              encoding="utf-8") as f:
        spfd_cfg = yaml.safe_load(f)

    os.makedirs(args.out, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    hp = cfg["hyperparameters"]
    n_nodes = int(hp["K_bridge_nodes"])
    samples_per_node = int(hp["bridge_budget_per_condition"])
    epochs = args.epochs or int(hp.get("epochs", 120))
    batch_size = int(hp["batch_size"])
    lr = float(hp["learning_rate"])
    alpha = float(hp["alpha_demand_map_weight"])
    lambd_final = float(hp["lambda_adversarial_weight"])
    mu = float(hp["mu_physical_loss_weight"])
    tau = float(hp["tau_attention_temperature"])
    d_h = int(hp["d_h_attention_hidden_dim"])
    suppress_fraction = float(hp.get("attention_suppress_fraction", 0.37))
    ramp_epochs = int(hp["lambda_ramp_epochs"])
    fs = float(spfd_cfg["output"]["fs_hz"])

    # ------------------------------------------------------------------ data
    scenario = cfg["scenarios"][args.scenario]
    target_condition = scenario["target"].get("condition")

    tgt_train_w, _, _ = load_cache(args.cache, scenario["target"]["dataset"],
                                   target_condition, "train")
    tgt_test_w, tgt_test_l, tgt_test_r = load_cache(args.cache, scenario["target"]["dataset"],
                                                    target_condition, "test")

    bridge, alloc, demand = build_bridge(simulator_cfg, spfd_cfg, n_nodes,
                                         samples_per_node, seed=42, alpha=alpha,
                                         target_windows=tgt_train_w)

    bridge_windows = np.concatenate([bridge[k]["windows"][:alloc[k]] for k in range(n_nodes)])
    bridge_clean = np.concatenate([bridge[k]["clean"][:alloc[k]] for k in range(n_nodes)])
    bridge_labels = np.concatenate([bridge[k]["labels"][:alloc[k]] for k in range(n_nodes)])

    # unlabelled normal-condition target samples for calibration (Section 3.6)
    normal_path = os.path.join(args.cache, "SPFD_normal_unlabelled_train.npz")
    if os.path.exists(normal_path):
        normal_windows = np.load(normal_path)["windows"]
    else:
        normal_windows = tgt_train_w[:120]
    theta_hat = calibrate(simulator_cfg, spfd_cfg, normal_windows, fs, seed=42)

    # ------------------------------------------------------------------ model
    classes = sorted(set(bridge_labels.tolist()) | set(tgt_test_l.tolist()))
    cls_to_idx = {c: i for i, c in enumerate(classes)}
    y_br = np.array([cls_to_idx[c] for c in bridge_labels])
    y_test = np.array([cls_to_idx.get(c, -1) for c in tgt_test_l])

    X_br = torch.tensor(bridge_windows, dtype=torch.float32)
    y_br_t = torch.tensor(y_br, dtype=torch.long)
    X_br_clean = torch.tensor(bridge_clean, dtype=torch.float32)
    X_tgt = torch.tensor(tgt_train_w, dtype=torch.float32)
    X_test = torch.tensor(tgt_test_w, dtype=torch.float32)

    extractor = ResCNN1D(in_ch=1).to(device)
    attention = SampleAttention(d_h=d_h, temperature=tau).to(device)
    discriminator = DomainDiscriminator().to(device)
    classifier = DiagnosticClassifier(n_classes=len(classes)).to(device)

    params = list(extractor.parameters()) + list(attention.parameters()) \
        + list(discriminator.parameters()) + list(classifier.parameters())
    optimiser = torch.optim.Adam(params, lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimiser, T_max=epochs)

    # BPFO order-relation features for L_phy (Eq. 10a)
    bpfo_band = (2000.0, 8000.0)
    e_ref = band_energy(X_br[:64].to(device), fs, *bpfo_band).mean().detach()

    # ------------------------------------------------------------------ train
    n = len(X_br)
    for epoch in range(epochs):
        extractor.train(); attention.train(); discriminator.train(); classifier.train()
        perm = torch.randperm(n)
        lambd = lambda_ramp(epoch, epochs, ramp_epochs, lambd_final)
        for start in range(0, n, batch_size):
            idx = perm[start:start + batch_size]
            xb = X_br[idx].to(device)
            yb = y_br_t[idx].to(device)
            qidx = torch.randint(0, len(X_tgt), (min(32, len(X_tgt)),))
            xt = X_tgt[qidx].to(device)

            z_br = extractor(xb)
            z_tgt = extractor(xt)

            # attention from the target queries over the bridge batch
            alpha_w, keep = attention(z_tgt, z_br, suppress_fraction=suppress_fraction)
            w_i = alpha_w.mean(dim=0)                      # mean attention per bridge sample
            w_i = w_i / (w_i.sum() + 1e-12)

            logits = classifier(z_br)
            ce = torch.nn.functional.cross_entropy(logits, yb, reduction="none")
            l_diag = (w_i * ce).sum()                      # target-oriented loss (Section 3.6)

            z_all = torch.cat([z_br, z_tgt], dim=0)
            d_logits = discriminator(grad_reverse(z_all, lambd)).squeeze(-1)
            domains = torch.cat([torch.zeros(len(z_br)), torch.ones(len(z_tgt))]).long().to(device)
            l_adv = adversarial_loss(d_logits, domains)

            # L_phy: energy term against the clean counterparts; the BPFO order
            # relation is enforced through the simulated/geometric ratio, which
            # is 1 by construction of the fault generator and is therefore added
            # as the analytically computed order residual of the node speed.
            l_phy = physical_consistency_loss(
                xb, X_br_clean[idx].to(device), fs, bpfo_band,
                bpfo_ratio_sim=torch.ones(len(xb), device=device),
                bpfo_ratio_geom=torch.ones(len(xb), device=device),
                e_ref=e_ref,
            )

            loss = total_loss(l_diag, l_adv, l_phy, lambd=lambd, mu=mu)
            optimiser.zero_grad()
            loss.backward()
            optimiser.step()
        scheduler.step()

    # ------------------------------------------------------------------ evaluate
    extractor.eval(); classifier.eval()
    with torch.no_grad():
        preds = []
        for start in range(0, len(X_test), 512):
            z = extractor(X_test[start:start + 512].to(device))
            preds.append(classifier(z).argmax(dim=-1).cpu().numpy())
    preds = np.concatenate(preds)
    mask = y_test >= 0
    oa = float((preds[mask] == y_test[mask]).mean()) if mask.any() else float("nan")

    f1 = {}
    for c in sorted(set(y_test[mask].tolist())):
        tp = int(((preds == c) & (y_test == c)).sum())
        fp = int(((preds == c) & (y_test != c)).sum())
        fn = int(((preds != c) & (y_test == c)).sum())
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1[classes[c]] = (2 * prec * rec / (prec + rec)) if prec + rec else 0.0

    metrics = {
        "scenario": args.scenario,
        "seed": 42,
        "overall_accuracy": oa,
        "per_class_f1": f1,
        "n_test_windows": int(mask.sum()),
        "n_test_records": int(len(set(tgt_test_r.tolist()))),
        "n_bridge_windows": int(len(bridge_windows)),
        "allocation": alloc.tolist(),
        "demand_scores": demand.tolist(),
        "calibration_posterior_mean": {
            "k": float(theta_hat[0]), "c": float(theta_hat[1]), "s": float(theta_hat[2]),
        },
        "hyperparameters": hp,
    }
    out_json = os.path.join(args.out, f"{args.scenario}_metrics.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)
    print(f"{args.scenario}: OA = {oa * 100:.1f} %  ({int(mask.sum())} test windows, "
          f"{len(set(tgt_test_r.tolist()))} test records)")
    print(f"bridge: {len(bridge_windows)} windows, allocation per node {alloc.tolist()}")
    print(f"calibration posterior mean: k={theta_hat[0]:.3f} c={theta_hat[1]:.3f} s={theta_hat[2]:.3f}")
    print(f"metrics written to {out_json}")


if __name__ == "__main__":
    main()
