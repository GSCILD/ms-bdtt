"""Sample-level attention over bridge samples (Eq. 9, Section 3.5.1).

    alpha_i = exp( ReLU( w2^T tanh( W1 [z_q ; z_{b,i}] ) ) )
              / sum_j exp( ReLU( w2^T tanh( W1 [z_q ; z_{b,j}] ) ) )

The hidden dimension of the attention head is d_h = 256 (approximately half of
the 512-d feature dimension); the temperature tau = 1.0 controls sharpness.
Bridge samples whose weight falls below the relevance threshold are suppressed;
across the five scenarios this removes 37 % of the bridge samples on average
(Figure 5a).
"""

from __future__ import annotations

import torch
import torch.nn as nn


class SampleAttention(nn.Module):
    """Two-layer MLP scoring concatenated query-bridge feature pairs."""

    def __init__(self, d_h: int = 256, temperature: float = 1.0):
        super().__init__()
        self.d_h = d_h
        self.temperature = float(temperature)
        self.W1 = nn.Linear(2 * 512, d_h)
        self.w2 = nn.Linear(d_h, 1)

    def scores(self, z_q: torch.Tensor, z_b: torch.Tensor) -> torch.Tensor:
        """Raw relevance scores s_i = w2^T tanh(W1 [z_q ; z_{b,i}]).

        z_q: (Bq, d) query features; z_b: (B, d) bridge features.
        Returns (Bq, B) scores.
        """
        Bq, d = z_q.shape
        B = z_b.shape[0]
        zq = z_q.unsqueeze(1).expand(Bq, B, d)
        zb = z_b.unsqueeze(0).expand(Bq, B, d)
        pair = torch.cat([zq, zb], dim=-1)                # (Bq, B, 2d)
        h = torch.tanh(self.W1(pair))                     # (Bq, B, d_h)
        return self.w2(torch.relu(h)).squeeze(-1) / self.temperature  # (Bq, B)

    def forward(self, z_q: torch.Tensor, z_b: torch.Tensor,
                suppress_fraction: float = 0.37) -> tuple[torch.Tensor, torch.Tensor]:
        """Attention weights and the retention mask.

        suppress_fraction: fraction of bridge samples with the lowest learned
        relevance that is suppressed (0.37 on average over the five scenarios).
        Returns (alpha (Bq, B), keep_mask (Bq, B) bool).
        """
        s = self.scores(z_q, z_b)
        alpha = torch.softmax(s, dim=-1)
        if suppress_fraction <= 0.0:
            return alpha, torch.ones_like(alpha, dtype=torch.bool)
        k = max(1, int(round(suppress_fraction * alpha.shape[-1])))
        # threshold at the (suppress_fraction) quantile of the weights (Figure 5a)
        threshold = torch.quantile(alpha, suppress_fraction, dim=-1, keepdim=True)
        keep = alpha >= threshold
        # guarantee exactly the lowest k samples are dropped per query
        order = torch.argsort(alpha, dim=-1)
        rank = torch.argsort(order, dim=-1)
        keep = rank >= k
        alpha = alpha * keep.float()
        alpha = alpha / (alpha.sum(dim=-1, keepdim=True) + 1e-12)
        return alpha, keep
