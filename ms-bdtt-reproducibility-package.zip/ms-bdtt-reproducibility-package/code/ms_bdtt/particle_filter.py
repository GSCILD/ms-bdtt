"""Bayesian particle-filter calibration of the digital twin (Algorithm 1, Appendix C.1).

State-space model (Section 3.4.1):

    theta_t = f(theta_{t-1}) + eps_t,   eps_t ~ N(0, Sigma_theta)
    Y_t     = h(theta_t, x_sim(theta_t)) + v_t,   v_t ~ N(0, Sigma_y)

State theta_t = [k, c, s]^T: stiffness correction k, damping correction c and
fault-severity scaling s. Process-noise standard deviations: 0.01 (k), 0.02 (c),
0.005 (s). The likelihood is a Gaussian observation model on the band-limited
spectral feature distance between simulated and measured vibration (Eq. 8) with
sigma = 0.1 calibrated from healthy baseline data. Systematic resampling is
triggered when the effective sample size falls below N/2 = 250.

The severity scaling s enters the fault-signal generator only and does not enter
the normal-condition observation model: the likelihood depends on (k, c) alone
(Section 3.4.1).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ParticleFilterConfig:
    n_particles: int = 500
    sigma: float = 0.1                 # likelihood scale (Eq. 8)
    process_std: tuple = (0.01, 0.02, 0.005)   # (k, c, s)
    ess_threshold_fraction: float = 0.5        # resample when ESS < N/2
    prior_mean: tuple = (1.0, 1.0, 0.15)
    prior_std: tuple = (0.10, 0.10, 0.05)
    bounds: tuple = ((0.5, 1.5), (0.5, 1.5), (0.0, 0.30))


def band_limited_spectrum(x: np.ndarray, fs: float, bands: list[tuple[float, float]]) -> np.ndarray:
    """Band-limited spectral feature vector Phi (Section 3.4.1).

    Energy of the signal in each of the fault characteristic frequency bands,
    normalised by the total energy.
    """
    X = np.abs(np.fft.rfft(x)) ** 2
    f = np.fft.rfftfreq(len(x), d=1.0 / fs)
    feats = []
    total = X.sum() + 1e-12
    for lo, hi in bands:
        mask = (f >= lo) & (f < hi)
        feats.append(X[mask].sum() / total)
    return np.asarray(feats)


def systematic_resample(weights: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Systematic resampling of particle indices."""
    n = len(weights)
    positions = (rng.random() + np.arange(n)) / n
    cumulative = np.cumsum(weights)
    cumulative[-1] = 1.0
    idx = np.searchsorted(cumulative, positions)
    return np.clip(idx, 0, n - 1)


class BayesianCalibrator:
    """Particle filter aligning the simulator with unlabelled normal-condition data."""

    def __init__(self, config: ParticleFilterConfig | None = None):
        self.cfg = config or ParticleFilterConfig()

    def initialise(self, rng: np.random.Generator) -> np.ndarray:
        """Draw N particles from the priors of Section 3.4.1.

        k: truncated normal centred on the FEA prediction, 10 % s.d.
        c: log-normal with median from healthy baseline tests
        s: uniform over the physically meaningful range
        """
        cfg = self.cfg
        n = cfg.n_particles
        k = np.clip(rng.normal(cfg.prior_mean[0], cfg.prior_std[0], n), *cfg.bounds[0])
        c = np.clip(rng.lognormal(np.log(cfg.prior_mean[1]), cfg.prior_std[1], n), *cfg.bounds[1])
        s = rng.uniform(*cfg.bounds[2], n)
        return np.stack([k, c, s], axis=1)   # (N, 3)

    def propagate(self, particles: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        """Random-walk process model f(.) (Eq. 6)."""
        cfg = self.cfg
        noise = rng.normal(0.0, 1.0, particles.shape) * np.asarray(cfg.process_std)
        out = particles + noise
        for j, (lo, hi) in enumerate(cfg.bounds):
            out[:, j] = np.clip(out[:, j], lo, hi)
        return out

    def log_likelihood(self, phi_sim: np.ndarray, phi_meas: np.ndarray) -> np.ndarray:
        """Gaussian likelihood on the band-limited spectral distance (Eq. 8)."""
        sigma = self.cfg.sigma
        d2 = ((phi_sim - phi_meas[None, :]) ** 2).sum(axis=1)
        return -d2 / (2.0 * sigma**2)

    def run(self, simulate_fn, phi_meas_series: list[np.ndarray],
            rng: np.random.Generator | None = None, update_s: bool = False) -> dict:
        """Run Algorithm 1.

        Parameters
        ----------
        simulate_fn : callable(theta (3,)) -> x_sim (1-D array)
            Simulator callable parameterised by the calibration state. The
            severity scaling s enters the fault-signal generator only.
        phi_meas_series : list of measured spectral feature vectors (one per
            assimilation step t = 1..T), from unlabelled normal-condition data.
        update_s : if False (default), the likelihood depends on (k, c) alone
            and s is not updated from healthy signals (Section 3.4.1).

        Returns
        -------
        dict with the posterior mean theta_hat = [k_hat, c_hat, s_hat], the
        per-step posterior means and the final effective sample size.
        """
        cfg = self.cfg
        rng = rng or np.random.default_rng(42)
        particles = self.initialise(rng)
        weights = np.full(cfg.n_particles, 1.0 / cfg.n_particles)
        history = []
        for t, phi_meas in enumerate(phi_meas_series):
            particles = self.propagate(particles, rng)
            phi_sim = np.stack([simulate_fn(p, t) for p in particles])
            log_w = self.log_likelihood(phi_sim, phi_meas)
            # s is not identified by normal-condition data: freeze it
            if not update_s:
                particles[:, 2] = particles[0, 2]
            log_w = log_w - log_w.max()
            weights = weights * np.exp(log_w)
            weights /= weights.sum() + 1e-12
            ess = 1.0 / np.sum(weights**2)
            if ess < cfg.n_particles * cfg.ess_threshold_fraction:
                idx = systematic_resample(weights, rng)
                particles = particles[idx]
                weights = np.full(cfg.n_particles, 1.0 / cfg.n_particles)
            theta_hat = (particles * weights[:, None]).sum(axis=0)
            history.append(theta_hat.copy())
        return {
            "theta_hat": history[-1],
            "history": np.stack(history),
            "final_ess": ess,
        }
