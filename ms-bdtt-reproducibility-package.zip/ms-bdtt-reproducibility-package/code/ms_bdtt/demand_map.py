"""Demand-guided sample allocation (Section 3.3, Eqs. 4-5).

    m(theta_o) = alpha * d_MMD( M_S(theta_o), M_t )
                 + (1 - alpha) * | d kappa / d s |                        (4)

    N_k = N_tot * m(theta_o(k)) / sum_j m(theta_o(j))                     (5)

The MMD term is estimated with a Gaussian RBF kernel whose bandwidth is set to
the median pairwise distance divided by log K; the sensitivity term is
approximated by training a reference classifier at each operating point with
varying fault severities and computing the finite difference of the accuracy.
Target-data hygiene: the MMD term is computed from source features and
unlabelled target features only; no target label and no target test sample
enters the demand map or the allocation rule (Section 3.3).
"""

from __future__ import annotations

import numpy as np


def mmd_rbf(X: np.ndarray, Y: np.ndarray, bandwidth: float | None = None) -> float:
    """Unbiased MMD^2 estimate with a Gaussian RBF kernel [18].

    Bandwidth defaults to the median pairwise distance divided by log K,
    following the standard practice of Section 3.3.
    """
    X = np.asarray(X, dtype=np.float64)
    Y = np.asarray(Y, dtype=np.float64)
    if bandwidth is None:
        Z = np.vstack([X, Y])
        d2 = ((Z[:, None, :] - Z[None, :, :]) ** 2).sum(-1)
        iu = np.triu_indices(len(Z), k=1)
        med = np.median(d2[iu]) if len(iu[0]) > 0 else 1.0
        bandwidth = np.sqrt(max(med, 1e-12)) / max(np.log(len(Z)), 1e-6)

    def k(A, B):
        d2 = ((A[:, None, :] - B[None, :, :]) ** 2).sum(-1)
        return np.exp(-d2 / (2.0 * bandwidth**2))

    n, m = len(X), len(Y)
    Kxx, Kyy, Kxy = k(X, X), k(Y, Y), k(X, Y)
    # unbiased estimators (exclude the diagonal)
    sum_xx = (Kxx.sum() - np.trace(Kxx)) / max(n * (n - 1), 1)
    sum_yy = (Kyy.sum() - np.trace(Kyy)) / max(m * (m - 1), 1)
    sum_xy = Kxy.mean()
    return float(max(sum_xx + sum_yy - 2.0 * sum_xy, 0.0))


def fault_sensitivity_gradient(reference_classifier,
                               features_by_severity: list[np.ndarray],
                               labels_by_severity: list[np.ndarray]) -> float:
    """|d kappa / d s|: finite difference of accuracy w.r.t. fault severity."""
    accs = []
    for feats, labels in zip(features_by_severity, labels_by_severity):
        pred = reference_classifier(feats)
        accs.append(float((pred == labels).mean()))
    if len(accs) < 2:
        return 0.0
    return abs(accs[-1] - accs[0]) / max(len(accs) - 1, 1)


def demand_map(mmd_term: float, sensitivity_term: float, alpha: float = 0.6) -> float:
    """Composite demand of Eq. (4); alpha = 0.6 weights domain separation higher."""
    return alpha * mmd_term + (1.0 - alpha) * sensitivity_term


def allocate(demand_scores: np.ndarray, n_total: int, min_per_node: int = 5) -> np.ndarray:
    """Allocation rule of Eq. (5), clipped to a minimum of five samples per node."""
    demand_scores = np.asarray(demand_scores, dtype=np.float64)
    k = len(demand_scores)
    if n_total < min_per_node * k:
        raise ValueError(f"budget {n_total} < {min_per_node} x {k} nodes")
    alloc = n_total * demand_scores / demand_scores.sum()
    alloc = np.maximum(np.floor(alloc).astype(int), min_per_node)
    # distribute the remainder by largest fractional part
    remainder = n_total - alloc.sum()
    frac = alloc - np.floor(alloc)
    order = np.argsort(-frac)
    for i in range(remainder):
        alloc[order[i % k]] += 1
    return alloc


def build_demand_scores(source_features_by_node: list[np.ndarray],
                        target_features: np.ndarray,
                        sensitivity_by_node: list[float],
                        alpha: float = 0.6) -> np.ndarray:
    """Composite demand per interpolation node (Eq. 4).

    Uses source features and unlabelled target features only.
    """
    scores = []
    for src_feats, sens in zip(source_features_by_node, sensitivity_by_node):
        d_mmd = mmd_rbf(src_feats, target_features)
        scores.append(demand_map(d_mmd, sens, alpha=alpha))
    return np.asarray(scores)
