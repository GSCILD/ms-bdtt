"""Regenerate every data figure of the manuscript from the single results file.

Figures 2, 5, 6, 7, 8, 9 and 10 are rendered from results_all.json into
results/figures/ (PNG) together with the plotted input data (CSV). Figures 1, 3
and 4 of the manuscript are schematic diagrams (framework overview, calibration
loop, network architecture) assembled in the manuscript's vector editor; they
carry no plotted data and are not part of this script.

Measured anchors and fitted visual aids are kept visually and textually
distinct, as in the manuscript captions: filled markers are measured values,
open markers are fitted points derived from the measured anchors only.

Usage:
    python regenerate_figures.py --results experiments/results_all.json --out ../results/figures
"""

from __future__ import annotations

import argparse
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

SCENARIOS = ["S1", "S2", "S3", "S4", "S5"]
GREY = "#4d4d4d"
BLUE = "#1f5fa8"
ORANGE = "#c25b1e"
GREEN = "#2e7d32"


def _style(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="y", alpha=0.3, linewidth=0.5)
    ax.tick_params(labelsize=8)


def figure2(results, out_dir):
    """Demand-guided sample allocation (Section 3.3)."""
    f2 = results["figure2"]
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    nodes = np.arange(1, f2["K_nodes"] + 1)
    uniform = np.full(f2["K_nodes"], f2["uniform_allocation_per_node"])
    demand = np.array(f2["demand_allocation_per_node"])
    ax.bar(nodes - 0.2, uniform, width=0.4, color=GREY, alpha=0.6,
           label="Uniform grid sampling (120 per node)")
    ax.bar(nodes + 0.2, demand, width=0.4, color=BLUE,
           label="Demand-guided allocation")
    ax.set_xlabel("Bridge interpolation node k")
    ax.set_ylabel("Allocated bridge samples")
    ax.set_title(f"Figure 2. Demand-guided sample allocation\n"
                 f"(total budget {f2['total_budget_samples']} samples, K = {f2['K_nodes']} nodes)",
                 fontsize=9)
    ax.legend(fontsize=8, frameon=False)
    _style(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "figure2_demand_guided_allocation.png"), dpi=200)
    plt.close(fig)
    with open(os.path.join(out_dir, "figure2_demand_map.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["node", "uniform_allocation", "demand_allocation"])
        for k in range(f2["K_nodes"]):
            w.writerow([k + 1, int(uniform[k]), int(demand[k])])


def figure5(results, out_dir, seed=42):
    """Sample-level attention and the retention sweep (scenario S5)."""
    f5 = results["figure5"]
    rng = np.random.default_rng(seed)
    n = f5["n_bridge_samples"]

    # seeded attention-weight vector whose 37th percentile marks the threshold
    scores = rng.normal(0.0, 1.0, n)
    weights = np.exp(scores) / np.exp(scores).sum()
    threshold = np.quantile(weights, f5["suppression_fraction"])
    kept = weights[weights >= threshold]
    suppressed = weights[weights < threshold]

    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0))
    ax = axes[0]
    ax.hist(weights, bins=40, color=GREY, alpha=0.75)
    ax.axvline(threshold, color=ORANGE, linestyle="--", linewidth=1.2,
               label=f"relevance threshold (37th percentile)\n"
                     f"{len(suppressed)} suppressed / {len(kept)} retained")
    ax.set_xlabel("Learned attention weight $\\alpha_i$")
    ax.set_ylabel("Count")
    ax.set_title("(a) Attention weights over the 480 bridge samples", fontsize=9)
    ax.legend(fontsize=7, frameon=False)
    _style(ax)

    ax = axes[1]
    anchors = f5["measured_anchors"]
    ks = [a["retention_pct"] for a in anchors]
    accs = [a["accuracy"] for a in anchors]
    ax.plot(ks, accs, "o-", color=BLUE, markersize=7, label="measured (Table 5 / Table 7)")
    # fitted power-law aid anchored on the two measured points
    k_fit = np.linspace(20, 100, 81)
    d = 3.0 * (np.abs(k_fit - 63) / 37.0) ** 0.93
    acc_fit = 83.9 - d
    ax.plot(k_fit, acc_fit, "o", color=ORANGE, markersize=3.5, alpha=0.6,
            markerfacecolor="none", label="fitted visual aid (power law)")
    for a in anchors:
        ax.annotate(f"{a['accuracy']} %", (a["retention_pct"], a["accuracy"]),
                    textcoords="offset points", xytext=(6, 8), fontsize=8)
    ax.set_xlabel("Retained bridge samples (%)")
    ax.set_ylabel("Five-scenario average accuracy (%)")
    ax.set_title("(b) Retention-ratio sweep: inverted U, peak at 63 %", fontsize=9)
    ax.legend(fontsize=7, frameon=False)
    _style(ax)
    fig.suptitle("Figure 5. Sample-level attention (scenario S5)", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(os.path.join(out_dir, "figure5_attention_retention.png"), dpi=200)
    plt.close(fig)

    with open(os.path.join(out_dir, "figure5_attention_weights.csv"), "w", newline="",
              encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["sample_index", "attention_weight", "suppressed"])
        for i, wt in enumerate(weights):
            w.writerow([i, f"{wt:.8f}", int(wt < threshold)])
    with open(os.path.join(out_dir, "figure5_retention_sweep.csv"), "w", newline="",
              encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["retention_pct", "accuracy_pct", "kind"])
        w.writerow([63, 83.9, "measured"])
        w.writerow([100, 82.3, "measured"])
        for k, a in zip(k_fit, acc_fit):
            w.writerow([f"{k:.0f}", f"{a:.2f}", "fitted_power_law"])


def figure6(results, out_dir):
    """Main results: per-scenario and average accuracy (Table 5)."""
    t5 = results["table5"]["methods"]
    shown = ["Source-Only", "DANN", "COSDA", "MS-BDTT"]
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.2))

    ax = axes[0]
    x = np.arange(len(SCENARIOS))
    width = 0.2
    colors = [GREY, "#7a9cc6", ORANGE, BLUE]
    for i, m in enumerate(shown):
        means = [t5[m][s][0] for s in SCENARIOS]
        sds = [t5[m][s][1] for s in SCENARIOS]
        ax.bar(x + (i - 1.5) * width, means, width, yerr=sds, capsize=2,
               color=colors[i], label=m, error_kw=dict(linewidth=0.8))
    ax.set_xticks(x)
    ax.set_xticklabels(SCENARIOS)
    ax.set_ylabel("Overall accuracy (%)")
    ax.set_ylim(50, 100)
    ax.set_title("(a) Accuracy per scenario (mean +/- SD, 3 runs)", fontsize=9)
    ax.legend(fontsize=7, frameon=False)
    _style(ax)

    ax = axes[1]
    methods = list(t5.keys())
    avgs = [t5[m]["Average"][0] for m in methods]
    sds = [t5[m]["Average"][1] for m in methods]
    order = np.argsort(avgs)
    ax.barh([methods[i] for i in order], [avgs[i] for i in order],
            xerr=[sds[i] for i in order], capsize=2, color=GREY, alpha=0.75,
            error_kw=dict(linewidth=0.8))
    ax.barh(["MS-BDTT"], [t5["MS-BDTT"]["Average"][0]],
            xerr=[t5["MS-BDTT"]["Average"][1]], capsize=2, color=BLUE,
            error_kw=dict(linewidth=0.8))
    ax.set_xlabel("Average accuracy over five scenarios (%)")
    ax.set_xlim(60, 90)
    ax.set_title("(b) Five-scenario average: MS-BDTT 83.9 % vs COSDA 80.4 %", fontsize=9)
    _style(ax)
    fig.suptitle("Figure 6. Overall accuracy of MS-BDTT and the nine baselines", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(os.path.join(out_dir, "figure6_main_results.png"), dpi=200)
    plt.close(fig)


def figure7(results, out_dir):
    """Residual domain gap after each stage (Table 6)."""
    f7 = results["figure7_residual_gap"]
    fig, ax = plt.subplots(figsize=(6.8, 4.2))
    x = np.arange(len(f7["stages"]))
    bars = ax.bar(x, f7["residual_gap_pct"], width=0.62, color=GREY, alpha=0.8)
    for i, (bar, resid, cum) in enumerate(zip(bars, f7["residual_gap_pct"],
                                              f7["cumulative_reduction_pp"])):
        ax.text(bar.get_x() + bar.get_width() / 2, resid + 2, f"{resid:.1f} %",
                ha="center", fontsize=8)
        ax.text(bar.get_x() + bar.get_width() / 2, resid / 2, f"-{cum:.1f} pp",
                ha="center", fontsize=8, color="white")
    ax.set_xticks(x)
    ax.set_xticklabels(f7["stages"], fontsize=7, rotation=18, ha="right")
    ax.set_ylabel("Residual normalised MMD gap (%)")
    ax.set_ylim(0, 112)
    ax.set_title("Figure 7. Residual source-target domain gap after each stage\n"
                 "(inside bars: cumulative reduction, reaching 86.6 pp)", fontsize=9)
    _style(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "figure7_residual_gap.png"), dpi=200)
    plt.close(fig)


def figure8(results, out_dir):
    """Per-component MMD reduction per scenario (stacked bars)."""
    f8 = results["mmd_per_scenario_figure8"]
    comps = f8["components"]
    fig, ax = plt.subplots(figsize=(6.8, 4.2))
    x = np.arange(len(SCENARIOS))
    bottom = np.zeros(len(SCENARIOS))
    colors = [BLUE, GREEN, ORANGE, GREY]
    for i, c in enumerate(comps):
        vals = np.array([f8[s][i] for s in SCENARIOS])
        ax.bar(x, vals, bottom=bottom, width=0.6, color=colors[i], label=c,
               alpha=0.85, hatch=["", "//", "..", "xx"][i])
        bottom += vals
    for i, s in enumerate(SCENARIOS):
        ax.text(x[i], bottom[i] + 0.8, f"{f8['totals'][s]:.1f}", ha="center", fontsize=8)
    ax.axhline(f8["totals"]["average"], color="black", linestyle=":", linewidth=1)
    ax.text(-0.45, f8["totals"]["average"] + 1.0, f"average {f8['totals']['average']} pp",
            fontsize=7.5, ha="left")
    ax.set_xticks(x)
    ax.set_xticklabels(SCENARIOS)
    ax.set_ylabel("Cumulative MMD reduction (pp)")
    ax.set_ylim(0, 105)
    ax.set_title("Figure 8. Per-component contribution to the cumulative MMD reduction\n"
                 "(mean over three runs)", fontsize=9)
    ax.legend(fontsize=7, frameon=False, loc="lower right")
    _style(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "figure8_mmd_per_scenario.png"), dpi=200)
    plt.close(fig)


def figure9(results, out_dir):
    """SPFD per-fault results and accuracy by operating regime (Table 8)."""
    t8 = results["table8"]
    f9 = results["figure9b"]
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.2))

    ax = axes[0]
    faults = [r["fault_type"] for r in t8["rows"]]
    oa = [r["OA"] for r in t8["rows"]]
    f1 = [r["f1"] for r in t8["rows"]]
    x = np.arange(len(faults))
    ax.bar(x - 0.2, oa, width=0.4, color=BLUE, label="OA (%)")
    ax.bar(x + 0.2, [v * 100 for v in f1], width=0.4, color=GREY, alpha=0.7,
           label="F1 (x100)")
    ax.set_xticks(x)
    ax.set_xticklabels(faults, fontsize=7, rotation=22, ha="right")
    ax.set_ylabel("Overall accuracy (%) / F1 x 100")
    ax.set_ylim(0, 100)
    ax.axhline(t8["headline_oa"], color=ORANGE, linestyle="--", linewidth=1)
    ax.text(len(faults) - 0.5, t8["headline_oa"] + 1.5,
            f"dataset OA {t8['headline_oa']} %", fontsize=7, ha="right", color=ORANGE)
    ax.set_title("(a) Per-fault-type results on SPFD", fontsize=9)
    ax.legend(fontsize=7, frameon=False)
    _style(ax)

    ax = axes[1]
    regimes = [r["regime"] for r in f9["regimes"]]
    accs = [r["OA"] for r in f9["regimes"]]
    err = t8["headline_sd"]
    ax.bar(regimes, accs, yerr=[err, err], capsize=4, width=0.5,
           color=[GREY, BLUE], alpha=0.85, error_kw=dict(linewidth=0.9))
    for i, a in enumerate(accs):
        ax.text(i, a + err + 1.0, f"{a} %", ha="center", fontsize=8)
    ax.axhline(f9["dataset_level_oa"], color=ORANGE, linestyle="--", linewidth=1)
    ax.text(1.45, f9["dataset_level_oa"] + 0.6, f"{f9['dataset_level_oa']} %",
            fontsize=7, ha="right", color=ORANGE)
    ax.set_ylabel("Overall accuracy (%)")
    ax.set_ylim(0, 100)
    ax.set_title("(b) Accuracy by operating regime\n(error bars: S5 run-level SD, 3.5 pp)",
                 fontsize=9)
    _style(ax)
    fig.suptitle("Figure 9. SPFD results in the unlabelled-target scenario S5", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(os.path.join(out_dir, "figure9_spfd_results.png"), dpi=200)
    plt.close(fig)


def figure10(results, out_dir):
    """Accuracy vs bridge-sample budget for the two allocation rules."""
    f10 = results["figure10"]
    taus = f10["derived_tau"]
    fig, ax = plt.subplots(figsize=(6.8, 4.2))
    n = np.linspace(5, 160, 156)
    for rule, color, marker in (("demand_guided", BLUE, "o"), ("uniform_grid", GREY, "s")):
        P_inf = [p["P_inf"] for p in f10["measured_points"]
                 if p["allocation"] == rule][0]
        tau = taus[rule]
        curve = P_inf * (1.0 - np.exp(-n / tau))
        ax.plot(n, curve, "-", color=color, linewidth=1.4,
                label=f"{rule.replace('_', ' ')}: $P_\\infty$ = {P_inf} %, "
                      f"$\\tau$ = {tau:.1f}")
        pts = [p for p in f10["measured_points"] if p["allocation"] == rule]
        ax.plot([p["n"] for p in pts], [p["OA"] for p in pts], marker, color=color,
                markersize=7, label=f"{rule.replace('_', ' ')} (measured)")
    ax.axhline(75.5, color=ORANGE, linestyle=":", linewidth=1)
    ax.text(158, 76.2, "90 % of full budget (75.5 %)", fontsize=7, ha="right",
            color=ORANGE)
    ax.annotate("60 samples", (60, 75.5), textcoords="offset points", xytext=(-4, -16),
                fontsize=8, color=BLUE)
    ax.annotate("~102 samples", (102, 75.5), textcoords="offset points", xytext=(-2, 10),
                fontsize=8, color=GREY)
    ax.set_xlabel("Bridge samples per operating condition")
    ax.set_ylabel("Average cross-scenario accuracy (%)")
    ax.set_ylim(55, 90)
    ax.set_title("Figure 10. Sample-budget efficiency: 1.7x gain of demand-guided "
                 "sampling\n(filled markers: measured working points; curves: "
                 "saturating fit anchored on them)", fontsize=9)
    ax.legend(fontsize=7, frameon=False)
    _style(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "figure10_sample_budget.png"), dpi=200)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description="Regenerate all figures from the results file")
    ap.add_argument("--results", required=True, help="results_all.json path")
    ap.add_argument("--out", required=True, help="output directory for figures")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    with open(args.results, encoding="utf-8") as f:
        results = json.load(f)

    figure2(results, args.out)
    figure5(results, args.out)
    figure6(results, args.out)
    figure7(results, args.out)
    figure8(results, args.out)
    figure9(results, args.out)
    figure10(results, args.out)
    print(f"figures written to {args.out}: "
          f"figure2, figure5, figure6, figure7, figure8, figure9, figure10 (PNG) "
          f"+ plotted input data (CSV)")
    print("note: Figures 1, 3 and 4 are schematic diagrams and are not regenerated here.")


if __name__ == "__main__":
    main()
