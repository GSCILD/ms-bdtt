"""MarineSim — parameterised rotordynamic simulator for marine propulsion plants.

Public modules:
    rotordynamics  — Timoshenko shaft model, fault injection, Newmark integration
    noise_model    — sensor/ambient noise chain and mounting response
"""

from .rotordynamics import (
    RotorModel,
    TimoshenkoElement,
    bearing_characteristic_frequencies,
    simulate_signal,
)

__all__ = [
    "RotorModel",
    "TimoshenkoElement",
    "bearing_characteristic_frequencies",
    "simulate_signal",
]
