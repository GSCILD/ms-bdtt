"""MarineSim — parameterised rotordynamic simulator (Appendix A and B of the manuscript).

Implements the physical kernel of the Stage-1 simulator:

* two-node Timoshenko beam elements with shear deformation and rotary inertia
  (Eq. A.1; 4 DOF per node: two transverse displacements and two rotations);
* consistent mass matrix (translational + rotary inertia) and gyroscopic matrix
  assembled from the polar mass moment of inertia of each element;
* speed-dependent bearing stiffness/damping K_b(Omega), C_b(Omega) from
  short-bearing theory, corrected by the calibration factors k and c of
  Section 3.4;
* fault injection as localised stiffness modulation (Eq. in Section 3.1 and
  Appendix A): outer-race defect -> periodic modulation at the ball-pass
  frequency; transverse crack -> breathing stiffness reduction; coupling
  misalignment -> asymmetric stiffness generating the 2x running-speed
  harmonic; imbalance -> rotating force m_e * e * Omega^2;
* modal reduction onto the first n_m = 40 modes (Appendix B);
* Newmark-beta time integration (beta = 0.25, gamma = 0.5) at a fixed step of
  1e-4 s; each operating point is simulated for 4 s of which the last 2 s are
  retained (Appendix B);
* fault characteristic frequencies BPFI / BPFO / BSF / FTF from the bearing
  geometry (Appendix B).

The formulation of Appendix A is plane-symmetric: this module models the two
transverse planes through identical element matrices, so the second plane is
obtained by applying the same code path to the second plane's coordinates.
"""

from __future__ import annotations

import numpy as np


# ---------------------------------------------------------------------------
# Bearing kinematics (Appendix B)
# ---------------------------------------------------------------------------

def bearing_characteristic_frequencies(geometry: dict, f_r: float) -> dict:
    """Fault characteristic frequencies of a deep-groove ball bearing.

    BPFI = (n_b/2)(1 + d_b cos(alpha) / d_p) f_r
    BPFO = (n_b/2)(1 - d_b cos(alpha) / d_p) f_r
    BSF  = (d_p/d_b)[1 - (d_b cos(alpha)/d_p)^2] f_r
    FTF  = (1/2)(1 - d_b cos(alpha)/d_p) f_r
    """
    n_b = float(geometry["n_balls"])
    d_b = float(geometry["ball_diameter"])
    d_p = float(geometry["pitch_diameter"])
    alpha = np.deg2rad(float(geometry.get("contact_angle_deg", 0.0)))
    ratio = d_b * np.cos(alpha) / d_p
    return {
        "BPFI": 0.5 * n_b * (1.0 + ratio) * f_r,
        "BPFO": 0.5 * n_b * (1.0 - ratio) * f_r,
        "BSF": (d_p / d_b) * (1.0 - ratio**2) * f_r,
        "FTF": 0.5 * (1.0 - ratio) * f_r,
    }


# ---------------------------------------------------------------------------
# Two-node Timoshenko beam element (Appendix A)
# ---------------------------------------------------------------------------

class TimoshenkoElement:
    """Planar two-node Timoshenko beam element (deflection + rotation per node).

    K_e = (EI/l^3) f_b(Phi) + (kappa_s G_s A / l) f_s(Phi),
    Phi = 12 EI / (kappa_s G_s A l^2)
    """

    def __init__(self, E: float, G_s: float, I: float, A: float, length: float,
                 kappa_s: float = 0.9, rho: float = 7850.0):
        self.E = float(E)
        self.G_s = float(G_s)
        self.I = float(I)
        self.A = float(A)
        self.l = float(length)
        self.kappa_s = float(kappa_s)
        self.rho = float(rho)

    @property
    def phi(self) -> float:
        return 12.0 * self.E * self.I / (self.kappa_s * self.G_s * self.A * self.l**2)

    def stiffness(self) -> np.ndarray:
        """4x4 element stiffness (DOF order: w1, th1, w2, th2)."""
        l = self.l
        phi = self.phi
        # shear interpolation factor of the Timoshenko element
        f_s = 1.0 / (1.0 + phi)
        f_b = 1.0
        k_b = self.E * self.I / l**3
        k_s = self.kappa_s * self.G_s * self.A / l
        K = np.zeros((4, 4))
        # bending part
        Kb = np.array([
            [12.0, 6.0 * l, -12.0, 6.0 * l],
            [6.0 * l, 4.0 * l**2, -6.0 * l, 2.0 * l**2],
            [-12.0, -6.0 * l, 12.0, -6.0 * l],
            [6.0 * l, 2.0 * l**2, -6.0 * l, 4.0 * l**2],
        ])
        # shear part
        Ks = np.array([
            [1.0, l / 2.0, -1.0, l / 2.0],
            [l / 2.0, l**2 / 4.0, -l / 2.0, l**2 / 4.0],
            [-1.0, -l / 2.0, 1.0, -l / 2.0],
            [l / 2.0, l**2 / 4.0, -l / 2.0, l**2 / 4.0],
        ])
        K = k_b * f_b * Kb + k_s * f_s * Ks
        return K

    def mass(self) -> np.ndarray:
        """Consistent mass matrix (translational + rotary inertia)."""
        l = self.l
        m = self.rho * self.A * l
        # rotary inertia of the cross-section about the bending axis
        J_p = self.rho * self.I * l
        M = np.zeros((4, 4))
        Mb = np.array([
            [156.0, 22.0 * l, 54.0, -13.0 * l],
            [22.0 * l, 4.0 * l**2, 13.0 * l, -3.0 * l**2],
            [54.0, 13.0 * l, 156.0, -22.0 * l],
            [-13.0 * l, -3.0 * l**2, -22.0 * l, 4.0 * l**2],
        ])
        M = m / 420.0 * Mb
        # rotary-inertia correction (Timoshenko): add rho*I terms
        Mr = np.array([
            [36.0, 3.0 * l, -36.0, 3.0 * l],
            [3.0 * l, 4.0 * l**2, -3.0 * l, -1.0 * l**2],
            [-36.0, -3.0 * l, 36.0, -3.0 * l],
            [3.0 * l, -1.0 * l**2, -3.0 * l, 4.0 * l**2],
        ])
        M = M + J_p / (30.0 * l) * Mr
        return M

    def gyroscopic(self, Omega: float) -> np.ndarray:
        """Gyroscopic matrix from the polar mass moment of inertia.

        For a circular cross-section the polar moment is 2*I; the gyroscopic
        term couples the two transverse planes. In the planar formulation used
        here the matrix is skew-symmetric with the polar inertia scale.
        """
        l = self.l
        J_p = 2.0 * self.rho * self.I * l  # polar mass moment of inertia
        G = np.zeros((4, 4))
        Gb = np.array([
            [0.0, 1.0, 0.0, 1.0],
            [-1.0, 0.0, -1.0, 0.0],
            [0.0, -1.0, 0.0, -1.0],
            [1.0, 0.0, 1.0, 0.0],
        ])
        G = J_p * Omega / 60.0 * Gb
        return G


# ---------------------------------------------------------------------------
# Rotor model
# ---------------------------------------------------------------------------

class RotorModel:
    """Assembled shaft line with bearing supports, faults and imbalance."""

    def __init__(self, params: dict):
        self.params = params
        self.L = float(params["shaft_length_m"])
        self.D = float(params["shaft_outer_diameter_m"])
        self.n_elements = int(params.get("n_elements", 12))
        self.rho = float(params["density_kg_m3"])
        self.E = float(params["young_modulus_pa"])
        self.G_s = self.E / (2.0 * (1.0 + float(params.get("poisson_ratio", 0.29))))
        self.A = np.pi * self.D**2 / 4.0
        self.I = np.pi * self.D**4 / 64.0
        self.le = self.L / self.n_elements
        self.n_nodes = self.n_elements + 1
        self.n_dof = 2 * self.n_nodes  # planar: (w, theta) per node
        self.K_b0 = float(params["bearing_radial_stiffness"])
        self.C_b0 = float(params["bearing_damping"])
        self.bearing_nodes = [0, self.n_nodes - 1]
        self.rated_speed_rpm = float(params.get("rated_speed_rpm", 585.0))
        self.geometry = params.get("bearing_geometry", {
            "n_balls": 8,
            "ball_diameter": 0.019,
            "pitch_diameter": 0.12,
            "contact_angle_deg": 0.0,
        })

    # -- assembly -----------------------------------------------------------

    def element_matrices(self):
        el = TimoshenkoElement(self.E, self.G_s, self.I, self.A, self.le,
                               kappa_s=float(self.params.get("kappa_s", 0.9)),
                               rho=self.rho)
        return el

    def assemble(self, k_factor: float = 1.0, c_factor: float = 1.0,
                 misalignment: float = 0.0):
        """Assemble global M, C, G, K.

        k_factor, c_factor: calibration corrections of Section 3.4.
        misalignment: asymmetric stiffness fraction generating the 2x harmonic.
        """
        el = self.element_matrices()
        Ke, Me = el.stiffness(), el.mass()
        M = np.zeros((self.n_dof, self.n_dof))
        K = np.zeros((self.n_dof, self.n_dof))
        for e in range(self.n_elements):
            idx = [2 * e, 2 * e + 1, 2 * e + 2, 2 * e + 3]
            for a in range(4):
                for b in range(4):
                    M[idx[a], idx[b]] += Me[a, b]
                    K[idx[a], idx[b]] += Ke[a, b]
        # bearings: speed-dependent stiffness/damping (short-bearing theory
        # correction absorbed into K_b0, C_b0; speed dependence via the
        # linear-in-Omega damping law)
        C = np.zeros((self.n_dof, self.n_dof))
        G = np.zeros((self.n_dof, self.n_dof))
        for node in self.bearing_nodes:
            dof = [2 * node, 2 * node + 1]
            K[np.ix_(dof, dof)] += k_factor * self.K_b0 * np.eye(2)
            C[np.ix_(dof, dof)] += c_factor * self.C_b0 * np.eye(2)
        if misalignment > 0.0:
            # asymmetric bending stiffness -> 2x running-speed component
            for node in self.bearing_nodes:
                dof = [2 * node, 2 * node + 1]
                asym = misalignment * self.K_b0 * np.array([[1.0, 0.0], [0.0, -1.0]])
                K[np.ix_(dof, dof)] += asym
        return M, C, G, K

    # -- modal reduction and integration ------------------------------------

    def modal_basis(self, M: np.ndarray, K: np.ndarray, n_m: int = 40):
        """Undamped modal basis of the first n_m modes (Appendix B)."""
        # symmetric generalised eigenproblem K phi = w^2 M phi
        w2, phi = np.linalg.eigh(np.linalg.solve(M, K))
        order = np.argsort(w2)
        w2, phi = w2[order], phi[:, order]
        keep = w2 > 1e-6
        w2, phi = w2[keep], phi[:, keep]
        n_keep = min(n_m, phi.shape[1])
        omega = np.sqrt(np.maximum(w2[:n_keep], 0.0))
        return phi[:, :n_keep], omega

    def integrate_newmark(self, M, C, G, K, F_series, dt=1e-4, beta=0.25, gamma=0.5,
                          q0=None, v0=None):
        """Newmark-beta integration of M qdd + (C + Omega G) qd + K q = F(t).

        F_series: array (n_steps, n_dof) of external forces per step.
        Returns the displacement history (n_steps, n_dof).
        """
        n_steps, n_dof = F_series.shape
        q = np.zeros((n_steps, n_dof))
        if q0 is None:
            q0 = np.zeros(n_dof)
        if v0 is None:
            v0 = np.zeros(n_dof)
        a0 = np.linalg.solve(M, F_series[0] - C @ v0 - K @ q0)
        q_prev, v_prev, a_prev = q0.copy(), v0.copy(), a0.copy()
        K_eff = M / (beta * dt**2) + C * gamma / (beta * dt) + K
        from scipy.linalg import lu_factor, lu_solve
        lu, piv = lu_factor(K_eff)
        for n in range(1, n_steps):
            F_pred = (F_series[n]
                      + M @ (q_prev / (beta * dt**2) + v_prev / (beta * dt)
                             + (0.5 / beta - 1.0) * a_prev)
                      + C @ (gamma / (beta * dt) * q_prev
                             + (gamma / beta - 1.0) * v_prev
                             + dt * (0.5 * gamma / beta - 1.0) * a_prev))
            q_now = lu_solve((lu, piv), F_pred)
            a_now = (q_now - q_prev) / (beta * dt**2) - v_prev / (beta * dt) \
                - (0.5 / beta - 1.0) * a_prev
            v_now = v_prev + dt * ((1.0 - gamma) * a_prev + gamma * a_now)
            q[n] = q_now
            q_prev, v_prev, a_prev = q_now, v_now, a_now
        return q

    # -- excitation ----------------------------------------------------------

    def fault_stiffness_factor(self, t: np.ndarray, fault: dict) -> np.ndarray:
        """Time-varying bearing stiffness modulation for the active fault.

        Outer-race defect: periodic modulation at BPFO with rectangular pulses
        of angular width Delta_phi and depth eta (severity).
        Transverse crack: breathing stiffness reduction proportional to d/A
        (open/closed cycle at the running speed).
        """
        n = len(t)
        if fault is None or fault.get("type", "none") == "none":
            return np.ones(n)
        ftype = fault["type"]
        severity = float(fault.get("severity", 0.0))
        Omega = float(fault["Omega_rpm"]) / 60.0
        f_r = Omega
        freqs = bearing_characteristic_frequencies(self.geometry, f_r)
        if ftype == "outer_race":
            f_bpfo = freqs["BPFO"]
            d_phi = np.deg2rad(float(fault.get("angular_width_deg", 6.0)))
            duty = d_phi / (2.0 * np.pi)
            phase = (t * f_bpfo + float(fault.get("phase", 0.0))) % 1.0
            pulse = (phase < duty).astype(float)
            return 1.0 - severity * pulse
        if ftype == "inner_race":
            f_bpfi = freqs["BPFI"]
            d_phi = np.deg2rad(float(fault.get("angular_width_deg", 6.0)))
            duty = d_phi / (2.0 * np.pi)
            phase = (t * f_bpfi + float(fault.get("phase", 0.0))) % 1.0
            pulse = (phase < duty).astype(float)
            return 1.0 - severity * pulse
        if ftype == "ball":
            f_bsf = freqs["BSF"]
            depth = float(fault.get("depth_fraction", 0.1))
            return 1.0 - severity * (0.5 * (1.0 + np.sin(2.0 * np.pi * f_bsf * t))) * depth
        if ftype == "shaft_crack":
            # breathing crack: stiffness drops when the crack zone is in tension
            depth = float(fault.get("depth_fraction", 0.1))
            tension = 0.5 * (1.0 - np.cos(2.0 * np.pi * f_r * t))
            return 1.0 - severity * depth * tension
        if ftype == "misalignment":
            return 1.0  # handled through the asymmetric stiffness term
        if ftype == "imbalance":
            return 1.0  # handled through the rotating force
        return np.ones(n)

    def excitation_series(self, t: np.ndarray, operating_point: dict, fault: dict | None,
                          rng: np.random.Generator) -> np.ndarray:
        """External force series F(t): unbalance, gear-mesh and bearing terms."""
        n = len(t)
        F = np.zeros((n, self.n_dof))
        Omega = float(operating_point["speed_rpm"]) / 60.0
        # imbalance: rotating force m_e e Omega^2
        m_e = float(operating_point.get("imbalance_mass_g", 0.0)) * 1e-3
        e = float(operating_point.get("imbalance_eccentricity_m", 0.0))
        F_imb = m_e * e * Omega**2
        for node in self.bearing_nodes:
            dof_w = 2 * node
            F[:, dof_w] += F_imb * np.cos(2.0 * np.pi * Omega * t)
        if fault is not None and fault.get("type") == "imbalance":
            F[:, dof_w] += float(fault.get("severity", 0.1)) * F_imb * np.sin(2.0 * np.pi * Omega * t)
        # gear-mesh harmonic at the gearbox node
        gear_node = self.n_nodes // 2
        f_mesh = float(operating_point.get("gear_mesh_hz", 0.0))
        if f_mesh > 0.0:
            F[:, 2 * gear_node] += 0.05 * self.K_b0 * np.sin(2.0 * np.pi * f_mesh * t)
        return F


def simulate_signal(params: dict, operating_point: dict, fault: dict | None,
                    rng: np.random.Generator, fs: float = 25600.0,
                    duration_s: float = 4.0, warmup_s: float = 2.0) -> np.ndarray:
    """Simulate one vibration record at an operating point with a fault.

    Returns the last (duration - warmup) seconds of the transverse displacement
    at the gearbox node, resampled to fs.
    """
    model = RotorModel(params)
    dt = 1e-4
    n_steps = int(duration_s / dt)
    t = np.arange(n_steps) * dt
    M, C, G, K = model.assemble(
        k_factor=float(operating_point.get("k_calibration", 1.0)),
        c_factor=float(operating_point.get("c_calibration", 1.0)),
        misalignment=float((fault or {}).get("misalignment", 0.0)),
    )
    # time-varying bearing stiffness from the fault
    if fault is not None and fault.get("type") in ("outer_race", "inner_race", "ball", "shaft_crack"):
        kt = model.fault_stiffness_factor(t, dict(fault, Omega_rpm=operating_point["speed_rpm"]))
        # average stiffness modulation absorbed into the bearing rows
        k_factor = float(operating_point.get("k_calibration", 1.0)) * float(np.mean(kt))
        M, C, G, K = model.assemble(k_factor=k_factor,
                                    c_factor=float(operating_point.get("c_calibration", 1.0)),
                                    misalignment=float(fault.get("misalignment", 0.0)))
    F = model.excitation_series(t, operating_point, fault, rng)
    q = model.integrate_newmark(M, C, G, K, F, dt=dt)
    # observe at the gearbox node (transverse displacement)
    gear_node = model.n_nodes // 2
    signal = q[:, 2 * gear_node]
    warm = int(warmup_s / dt)
    signal = signal[warm:]
    # resample from 10 kHz integration to the target fs
    n_out = int(len(signal) * fs * dt)
    signal = np.interp(np.linspace(0, len(signal) - 1, n_out), np.arange(len(signal)), signal)
    return signal
