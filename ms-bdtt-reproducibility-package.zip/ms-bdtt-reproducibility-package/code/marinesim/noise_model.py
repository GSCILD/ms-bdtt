"""MarineSim — structured noise injection and sensor model (Section 3.2).

x_noisy = x_sim + n_sensor(.) + n_ambient(.)

n_sensor: accelerometer artefacts
  * frequency-dependent noise floor: white below 1 kHz, 1/f above
  * quantisation error of 24-bit ADCs
  * baseline drift from temperature-induced sensor offsets
n_ambient: marine environmental disturbances
  * hull vibration transmitted through engine mounting compliance
  * wave-induced excitation between 0.1 and 2 Hz
  * flow turbulence around the propeller blades
H_s(f): mounting frequency response, resonance ~8 kHz (stud-mounted),
  rolling off at about -12 dB/octave above resonance.
"""

from __future__ import annotations

import numpy as np


def sensor_noise(n: int, fs: float, rng: np.random.Generator,
                 white_floor: float = 0.02, one_over_f_floor: float = 0.05,
                 corner_hz: float = 1000.0) -> np.ndarray:
    """Frequency-dependent accelerometer noise floor (white < 1 kHz, 1/f above)."""
    white = white_floor * rng.standard_normal(n)
    f = np.fft.rfftfreq(n, d=1.0 / fs)
    f_safe = np.maximum(f, 1.0)
    # 1/f magnitude above the corner, white below
    shape = np.where(f < corner_hz, 1.0, corner_hz / f_safe)
    pink = rng.standard_normal(len(f)) * shape
    pink = np.fft.irfft(pink, n=n)
    pink = one_over_f_floor * pink / (np.std(pink) + 1e-12)
    return white + pink


def quantise_24bit(x: np.ndarray, full_scale: float = 2.0) -> np.ndarray:
    """Quantisation error of a 24-bit ADC (two's complement, +/-full_scale)."""
    levels = 2**24
    step = 2.0 * full_scale / levels
    return np.round(x / step) * step


def baseline_drift(n: int, fs: float, rng: np.random.Generator,
                   drift_std: float = 0.01, cutoff_hz: float = 0.5) -> np.ndarray:
    """Temperature-induced baseline drift: low-passed random walk."""
    walk = np.cumsum(rng.standard_normal(n))
    walk = walk - walk.mean()
    # simple one-pole low-pass at cutoff_hz
    alpha = np.exp(-2.0 * np.pi * cutoff_hz / fs)
    y = np.zeros(n)
    for i in range(1, n):
        y[i] = alpha * y[i - 1] + (1.0 - alpha) * walk[i]
    return drift_std * y / (np.std(y) + 1e-12)


def hull_vibration(n: int, fs: float, rng: np.random.Generator,
                   mounting_resonance_hz: float = 12.0, q_factor: float = 8.0,
                   wave_band=(0.1, 2.0), amplitude: float = 0.05) -> np.ndarray:
    """Hull vibration through engine mounting compliance + wave excitation.

    Modelled as a resonant second-order response of the mounting system driven
    by wave-band excitation (0.1-2 Hz) and a broadband structural component.
    """
    t = np.arange(n) / fs
    # wave-band excitation
    f_wave = rng.uniform(wave_band[0], wave_band[1])
    wave = amplitude * np.sin(2.0 * np.pi * f_wave * t + rng.uniform(0, 2 * np.pi))
    # structural broadband component through the mounting resonance
    f = np.fft.rfftfreq(n, d=1.0 / fs)
    f_safe = np.maximum(f, 1.0)
    # mounting resonance: second-order resonance at mounting_resonance_hz
    r = f_safe / mounting_resonance_hz
    H = 1.0 / np.sqrt((1.0 - r**2) ** 2 + (r / q_factor) ** 2)
    spec = rng.standard_normal(len(f)) * H
    struct = np.fft.irfft(spec, n=n)
    struct = 0.5 * amplitude * struct / (np.std(struct) + 1e-12)
    return wave + struct


def flow_turbulence(n: int, rng: np.random.Generator, amplitude: float = 0.01,
                    cutoff_hz: float = 800.0) -> np.ndarray:
    """Propeller flow turbulence: band-limited noise below cutoff_hz."""
    noise = rng.standard_normal(n)
    f = np.fft.rfftfreq(n)
    f_safe = np.maximum(f, 1e-6)
    H = np.exp(-0.5 * (f_safe / cutoff_hz) ** 2)
    out = np.fft.irfft(np.fft.rfft(noise) * H, n=n)
    return amplitude * out / (np.std(out) + 1e-12)


def mounting_response(x: np.ndarray, fs: float,
                      resonance_hz: float = 8000.0, q_factor: float = 6.0,
                      rolloff_db_per_octave: float = 12.0) -> np.ndarray:
    """Accelerometer mounting response H_s(f).

    Resonant behaviour of the mounting system; above the resonance the
    response rolls off at about -12 dB/octave (Section 3.2).
    """
    n = len(x)
    f = np.fft.rfftfreq(n, d=1.0 / fs)
    f_safe = np.maximum(f, 1.0)
    r = f_safe / resonance_hz
    H_res = 1.0 / np.sqrt((1.0 - r**2) ** 2 + (r / q_factor) ** 2)
    # -12 dB/octave rolloff above resonance
    slope = 10.0 ** (-rolloff_db_per_octave / 20.0)
    H_roll = np.where(f > resonance_hz, (f_safe / resonance_hz) ** (-rolloff_db_per_octave / 20.0), 1.0)
    H = H_res * H_roll
    X = np.fft.rfft(x)
    return np.fft.irfft(X * H, n=n)


def apply_sensor_model(x_sim: np.ndarray, fs: float, rng: np.random.Generator,
                       params: dict | None = None) -> np.ndarray:
    """Full noise chain of Section 3.2, Eq. (3)."""
    p = params or {}
    n = len(x_sim)
    n_sensor = sensor_noise(n, fs, rng,
                            white_floor=p.get("white_floor", 0.02),
                            one_over_f_floor=p.get("one_over_f_floor", 0.05))
    n_sensor = n_sensor + baseline_drift(n, fs, rng,
                                         drift_std=p.get("drift_std", 0.01))
    n_ambient = hull_vibration(n, fs, rng,
                               amplitude=p.get("hull_amplitude", 0.05))
    n_ambient = n_ambient + flow_turbulence(n, rng,
                                            amplitude=p.get("turbulence_amplitude", 0.01))
    x_noisy = x_sim + n_sensor + n_ambient
    x_noisy = mounting_response(x_noisy, fs,
                                resonance_hz=p.get("mounting_resonance_hz", 8000.0))
    return quantise_24bit(x_noisy, full_scale=p.get("adc_full_scale", 2.0))
