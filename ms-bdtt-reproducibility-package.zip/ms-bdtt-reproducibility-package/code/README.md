# MS-BDTT code — run order and module map

Environment: Python 3.10+, PyTorch 2.0, CUDA 11.8 (`environment.yml` /
`requirements.txt`). All scripts are deterministic under seed 42.

## Run order

```bash
cd code

# 0. (once) download the four public datasets — see ../data/public_datasets.md

# 1. dataset manifests (verifies class counts against Tables 3 and 4a)
python preprocessing/make_manifests.py --out ../data/manifests

# 2. record-level split manifests for S1-S5 (seed 42)
python preprocessing/make_splits.py --out ../data/splits

# 3. windowed cache from the raw downloads (per scenario; repeat per dataset)
#    CWRU example:
python preprocessing/build_cache.py --root /path/to/CWRU \
    --manifest ../data/manifests/cwru_manifest.csv \
    --split ../data/splits/S1_split.json --out ../cache
#    XJTU-SY / Paderborn / SEU: pass --file-map for datasets whose repository
#    file naming is not encoded in the manifest (see build_cache.py docstring).

# 4. SPFD demonstration subset with MarineSim (seed 42; --demo = 100 windows/group)
python marinesim/generate_spfd.py --config marinesim/configs/spfd_config.yaml \
    --out ../data/spfd_demo --demo

# 5. train + evaluate one scenario (writes run-level metrics JSON)
python ms_bdtt/train.py --scenario S5 --config ../configs/ms_bdtt_trained_config.yaml \
    --cache ../cache --out ../results/run_level_predictions

# 6. regenerate every machine-readable table from the single results file
python experiments/regenerate_tables.py --results experiments/results_all.json \
    --out ../results/tables --run-level-out ../results/run_level_predictions

# 7. regenerate every figure
python experiments/regenerate_figures.py --results experiments/results_all.json \
    --out ../results/figures
```

## Module map

| Module | Contents |
|---|---|
| `marinesim/rotordynamics.py` | Timoshenko shaft model, bearing kinematics (BPFI/BPFO/BSF/FTF), fault injection, modal reduction, Newmark-beta integration (Appendices A-B) |
| `marinesim/noise_model.py` | Sensor/ambient noise chain, 24-bit quantisation, baseline drift, mounting response (Section 3.2) |
| `marinesim/generate_spfd.py` | SPFD generation (Section 4.1) and continuous-bridge generation (Eq. 2) |
| `marinesim/configs/` | `simulator_config.yaml` (Table A.1 parameters), `spfd_config.yaml` (SPFD definition) |
| `preprocessing/windowing.py` | 2048/50 %/1024 windowing, Table 4a label maps, split-integrity check |
| `preprocessing/make_manifests.py` | dataset manifests with verified class counts |
| `preprocessing/make_splits.py` | record-level 70/15/15 splits (seed 42) |
| `preprocessing/build_cache.py` | raw dataset files -> windowed NPZ cache |
| `ms_bdtt/model.py` | 1-D ResCNN [64,128,256,256,512,512], GRL, discriminator, classifier |
| `ms_bdtt/attention.py` | sample-level attention (Eq. 9) with relevance-threshold suppression |
| `ms_bdtt/particle_filter.py` | Bayesian calibration (Algorithm 1, Eqs. 6-8) |
| `ms_bdtt/losses.py` | L_diag, L_adv, L_phy (Eqs. 10, 10a), lambda ramp |
| `ms_bdtt/demand_map.py` | MMD (median-heuristic bandwidth), sensitivity gradient, allocation (Eqs. 4-5) |
| `ms_bdtt/train.py` | full training/evaluation pipeline |
| `experiments/results_all.json` | the single version-controlled results file |
| `experiments/regenerate_tables.py` | all table CSVs + run-level predictions + consistency checks |
| `experiments/regenerate_figures.py` | Figures 2, 5, 6, 7, 8, 9, 10 |

## Notes

* The training code requires the four public datasets (Section 4.1 citations);
  they are not redistributed in this deposit.
* `train.py` trains the full framework end to end: bridge generation, demand
  allocation, particle-filter calibration, attention-weighted adversarial
  training, evaluation on the disjoint target test set.
* The particle-filter likelihood depends on (k, c) alone; s is frozen during
  normal-only calibration (Section 3.4.1).
* Runtime of `train.py` on an RTX 4090 is approximately 85 min for the main
  experiments (Table 10); use `--epochs` for smoke tests.
