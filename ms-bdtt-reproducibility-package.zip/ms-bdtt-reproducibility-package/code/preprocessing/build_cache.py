"""Build a windowed NPZ cache from raw dataset files (one NPZ per dataset+condition).

The cache is the interface between the raw public datasets and the training
pipeline: each cache file stores the windowed signals and their mapped labels
for one (dataset, operating condition) pair, together with the record-level
split assignment so that windows never cross a partition boundary.

Usage:
    python build_cache.py --root <raw-dataset-root> --manifest ../../data/manifests/cwru_manifest.csv \
        --split ../../data/splits/S1_split.json --out cache/

For datasets whose repository file naming is not encoded in the manifest
(Paderborn, SEU), pass --file-map <json> binding record_id -> relative file
path under --root. CWRU uses the standard 48 kHz drive-end numbering
(97-249 .mat, X###_DE_time keys); XJTU-SY uses Bearing{i}_{j}/35Hz0{1,2}.csv.
"""

from __future__ import annotations

import argparse
import json
import os
from collections import defaultdict

import numpy as np
import pandas as pd

from windowing import sliding_windows
from windowing import (S3_CWRU_MAP, S3_XJTU_MAP, S4_PADERBORN_MAP, S4_SEU_MAP)


def _load_mat_signal(path: str) -> np.ndarray:
    from scipy.io import loadmat
    data = loadmat(path)
    keys = [k for k in data.keys() if not k.startswith("__")]
    for k in keys:  # prefer drive-end time series keys
        if "DE_time" in k or "DEtime" in k:
            return np.asarray(data[k]).ravel()
    return np.asarray(data[keys[0]]).ravel()


def _load_csv_signal(path: str) -> np.ndarray:
    df = pd.read_csv(path, header=None)
    return df.iloc[:, -1].to_numpy(dtype=np.float64)


def _load_seu_signal(path: str) -> np.ndarray:
    if path.endswith(".mat"):
        return _load_mat_signal(path)
    return _load_csv_signal(path)


def resolve_file(root: str, dataset: str, record: pd.Series, file_map: dict | None) -> str:
    rid = record["record_id"]
    if file_map and rid in file_map:
        return os.path.join(root, file_map[rid])
    if dataset == "CWRU":
        base = int(str(record["official_file"]).split(".")[0])
        hp = int(str(record["operating_condition"]).replace("HP", ""))
        return os.path.join(root, f"{base + hp}.mat")
    if dataset == "XJTU-SY":
        return os.path.join(root, record["official_file"])  # test folder
    raise FileNotFoundError(
        f"no file mapping for {dataset} record {rid}; pass --file-map")


LABEL_MAPS = {
    "CWRU": S3_CWRU_MAP,
    "XJTU-SY": S3_XJTU_MAP,
    "Paderborn": S4_PADERBORN_MAP,
    "SEU": S4_SEU_MAP,
}


def main():
    ap = argparse.ArgumentParser(description="Build windowed NPZ caches")
    ap.add_argument("--root", required=True, help="raw dataset root directory")
    ap.add_argument("--manifest", required=True, help="manifest CSV")
    ap.add_argument("--split", required=True, help="scenario split JSON")
    ap.add_argument("--out", required=True, help="output cache directory")
    ap.add_argument("--file-map", default=None, help="JSON: record_id -> relative path")
    ap.add_argument("--window", type=int, default=2048)
    ap.add_argument("--stride", type=int, default=1024)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    file_map = None
    if args.file_map:
        with open(args.file_map, encoding="utf-8") as f:
            file_map = json.load(f)
    with open(args.split, encoding="utf-8") as f:
        split_doc = json.load(f)

    partition = {}
    for side in ("sources", "targets"):
        for block in split_doc[side]:
            for rec in block["records"]:
                partition[rec["record_id"]] = rec["partition"]

    manifest = pd.read_csv(args.manifest)
    dataset = manifest["dataset"].iloc[0]
    label_map = LABEL_MAPS.get(dataset)

    buckets = defaultdict(list)
    for _, rec in manifest.iterrows():
        cond = rec["operating_condition"]
        path = resolve_file(args.root, dataset, rec, file_map)
        if dataset == "XJTU-SY":
            sig = np.concatenate([
                _load_csv_signal(os.path.join(path, "35Hz01.csv")),
                _load_csv_signal(os.path.join(path, "35Hz02.csv")),
            ])
        elif dataset == "SEU":
            sig = _load_seu_signal(path)
        else:
            sig = _load_mat_signal(path)
        wins = sliding_windows(sig, args.window, args.stride)
        shared = label_map.get(rec["original_class"]) if label_map else rec["original_class"]
        if shared is None:
            continue  # excluded class (e.g. Paderborn or_early in S4)
        rid = rec["record_id"]
        part = partition.get(rid, "train")
        for w in wins:
            buckets[(dataset, cond, part)].append((w, shared, rid))

    for (ds, cond, part), items in sorted(buckets.items()):
        windows = np.stack([i[0] for i in items]).astype(np.float32)
        labels = np.array([i[1] for i in items])
        records = np.array([i[2] for i in items])
        out = os.path.join(args.out, f"{ds}_{cond}_{part}.npz".replace(" ", ""))
        np.savez_compressed(out, windows=windows, labels=labels, records=records)
        print(f"{os.path.basename(out)}: {len(items)} windows, "
              f"{len(set(labels))} classes, {len(set(records))} records")

    all_records = defaultdict(set)
    for (_, _, part), items in buckets.items():
        for _, _, rid in items:
            all_records[rid].add(part)
    bad = {r: p for r, p in all_records.items() if len(p) > 1}
    assert not bad, f"records span partitions: {bad}"
    print("Integrity verified: no record spans partitions.")


if __name__ == "__main__":
    main()
