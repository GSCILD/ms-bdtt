"""Generate the record-level split manifests for scenarios S1-S5 (data/splits/).

Partitions are created at the original-record (file) level BEFORE window
segmentation; windows from the same record never cross a partition boundary
(Section 4.4). Grouping variables: dataset x record file x operating condition.
Assignment is deterministic under the master seed (42).

Split fractions: 70 % train / 15 % validation / 15 % test at the record level
(recorded in seeds.json).

Usage:
    python make_splits.py --out ../../data/splits
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from collections import defaultdict

import numpy as np

from windowing import verify_record_level_split
from make_manifests import cwru_records, xjtu_records, paderborn_records, \
    seu_records, spfd_records

SEED = 42
FRACTIONS = {"train": 0.70, "validation": 0.15, "test": 0.15}


def assign_partitions(record_ids: list[str], seed: int = SEED) -> dict[str, str]:
    """Deterministic record-level 70/15/15 assignment (seed 42)."""
    rng = np.random.default_rng(seed)
    ids = sorted(record_ids)
    rng.shuffle(ids)
    n = len(ids)
    n_train = max(1, int(np.floor(FRACTIONS["train"] * n)))
    n_val = max(1, int(np.floor(FRACTIONS["validation"] * n))) if n >= 5 else 1
    n_val = min(n_val, n - n_train - 1) if n - n_train >= 2 else n_val
    n_val = max(1, min(n_val, n - n_train - 1)) if n - n_train >= 2 else 0
    assignment = {}
    for i, rid in enumerate(ids):
        if i < n_train:
            assignment[rid] = "train"
        elif i < n_train + n_val:
            assignment[rid] = "validation"
        else:
            assignment[rid] = "test"
    return assignment


def build_record_inventory() -> list[dict]:
    """Flat record inventory across the five datasets (one row per record)."""
    rows = []
    for fn in (cwru_records, xjtu_records, paderborn_records, seu_records, spfd_records):
        for r in fn():
            rows.append({
                "dataset": r["dataset"],
                "record_id": r["record_id"],
                "operating_condition": r["operating_condition"],
                "original_class": r["original_class"],
                "windows": r["windows"],
            })
    # collapse to unique records (XJTU-SY manifest has several rows per test)
    uniq = {}
    for r in rows:
        key = (r["dataset"], r["record_id"], r["operating_condition"])
        if key not in uniq:
            uniq[key] = dict(r)
        else:
            uniq[key]["windows"] += r["windows"]
            uniq[key]["original_class"] = uniq[key]["original_class"]  # keep first
    return list(uniq.values())


SCENARIO_SPECS = {
    "S1": {
        "description": "Cross-load",
        "source": [("CWRU", "3HP")],
        "target": [("CWRU", "1HP")],
        "key_challenge": "Load shift",
    },
    "S2": {
        "description": "Cross-speed",
        "source": [("CWRU", "3HP")],
        "target": [("CWRU", "3HP")],
        "target_note": "CWRU 1797 r/min order-tracked and resampled to 1200 r/min "
                       "(synthesised condition, Section 4.2)",
        "key_challenge": "Speed variation",
    },
    "S3": {
        "description": "Cross-dataset",
        "source": [("CWRU", None)],
        "target": [("XJTU-SY", None)],
        "key_challenge": "Equipment difference",
    },
    "S4": {
        "description": "Cross-equipment (partial-domain)",
        "source": [("Paderborn", None)],
        "target": [("SEU", None)],
        "key_challenge": "Fault-signature mismatch",
    },
    "S5": {
        "description": "Unlabelled-target marine",
        "source": [("CWRU", None), ("XJTU-SY", None), ("Paderborn", None), ("SEU", None)],
        "target": [("SPFD", None)],
        "key_challenge": "No labelled target data",
    },
}


def records_for(inventory, dataset, condition=None):
    out = []
    for r in inventory:
        if r["dataset"] != dataset:
            continue
        if condition is not None and r["operating_condition"] != condition:
            continue
        out.append(r)
    return out


def main():
    ap = argparse.ArgumentParser(description="Generate record-level split manifests")
    ap.add_argument("--out", required=True, help="output directory for split JSONs")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    inventory = build_record_inventory()

    # global per-dataset assignment (records are shared across scenarios)
    assignment: dict[str, str] = {}
    by_dataset = defaultdict(list)
    for r in inventory:
        by_dataset[r["dataset"]].append(r["record_id"])
    for dataset, ids in by_dataset.items():
        assignment.update(assign_partitions(ids, seed=SEED))

    # integrity check: no record spans partitions
    verify_record_level_split(
        [{"dataset": r["dataset"], "record_id": r["record_id"],
          "operating_condition": r["operating_condition"]} for r in inventory],
        assignment,
    )

    for scenario, spec in SCENARIO_SPECS.items():
        doc = {
            "scenario": scenario,
            "description": spec["description"],
            "key_challenge": spec["key_challenge"],
            "seed": SEED,
            "split_level": "record (file) level, before window segmentation",
            "grouping_variables": ["dataset", "record_file", "operating_condition"],
            "fractions": FRACTIONS,
            "sources": [],
            "targets": [],
            "notes": [],
        }
        for dataset, condition in spec["source"]:
            recs = records_for(inventory, dataset, condition)
            doc["sources"].append({
                "dataset": dataset,
                "operating_condition": condition or "all",
                "role": "labelled source",
                "records": [
                    {"record_id": r["record_id"],
                     "operating_condition": r["operating_condition"],
                     "original_class": r["original_class"],
                     "windows": r["windows"],
                     "partition": assignment[r["record_id"]]}
                    for r in sorted(recs, key=lambda x: x["record_id"])
                ],
            })
        for dataset, condition in spec["target"]:
            recs = records_for(inventory, dataset, condition)
            doc["targets"].append({
                "dataset": dataset,
                "operating_condition": condition or "all",
                "role": "unlabelled target" if dataset == "SPFD" else "labelled target",
                "records": [
                    {"record_id": r["record_id"],
                     "operating_condition": r["operating_condition"],
                     "original_class": r["original_class"],
                     "windows": r["windows"],
                     "partition": assignment[r["record_id"]]}
                    for r in sorted(recs, key=lambda x: x["record_id"])
                ],
            })
        if "target_note" in spec:
            doc["notes"].append(spec["target_note"])
        if scenario == "S4":
            doc["notes"].append(
                "Partial-domain setting: the SEU breakage class is the unknown class; "
                "an unknown-class rejection rule is retained and the unknown-class "
                "rejection rate is reported in addition to closed-set OA (Section 4.2.1).")
        if scenario == "S5":
            doc["notes"].append(
                "Target labels are never used at any stage; only the 120 unlabelled "
                "normal-condition SPFD samples are used for Bayesian calibration "
                "(Section 3.6). The target-only classes (misalignment, cavitation, "
                "composite) are evaluated under a source-free protocol (Section 4.2.1).")
        out_path = os.path.join(args.out, f"{scenario}_split.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2, ensure_ascii=False)
        n_src = sum(len(s["records"]) for s in doc["sources"])
        n_tgt = sum(len(t["records"]) for t in doc["targets"])
        print(f"{scenario}_split.json: {n_src} source records, {n_tgt} target records")

    print("Split manifests written. Integrity verified: no record spans partitions.")


if __name__ == "__main__":
    main()
