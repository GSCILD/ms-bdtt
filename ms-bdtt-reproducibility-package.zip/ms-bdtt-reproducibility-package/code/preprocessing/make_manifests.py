"""Generate the dataset manifests (data/manifests/*.csv).

Encodes the record-level inventory of the five datasets used in the manuscript
and verifies that the emitted class counts match Table 3 and Table 4a exactly.
Re-running this script reproduces the shipped manifests bit-for-bit.

Usage:
    python make_manifests.py --out ../../data/manifests
"""

from __future__ import annotations

import argparse
import csv
import os

WINDOW_LENGTH = 2048
OVERLAP = "50%"
STRIDE = 1024

# ---------------------------------------------------------------------------
# Record inventories
# ---------------------------------------------------------------------------

def cwru_records():
    """CWRU: nine fault types x four motor loads (0/1/2/3 HP), drive-end 12 kHz.

    Window counts per record follow Table 4a: normal 3,200; inner-race (three
    sizes folded) 9,600; outer-race (three sizes folded) 9,600; ball 4,800;
    combined 3,200; total ~30,000 (Table 3).
    """
    classes = [
        # (record class, windows per load, official 48 kHz file index)
        ("normal", 800, None),
        ("ir_0.007", 800, 105), ("ir_0.014", 800, 169), ("ir_0.021", 800, 209),
        ("or_0.007", 800, 130), ("or_0.014", 800, 197), ("or_0.021", 800, 246),
        ("ball", 1200, 118),
        ("combined", 800, 137),
    ]
    rows = []
    for cls, win, fidx in classes:
        for hp in (0, 1, 2, 3):
            rows.append({
                "dataset": "CWRU",
                "record_id": f"CWRU_{cls}_{hp}HP",
                "operating_condition": f"{hp}HP",
                "original_class": cls,
                "windows": win,
                "channel": "DE",
                "fs_hz": 12000,
                "window_length": WINDOW_LENGTH,
                "overlap": OVERLAP,
                "stride": STRIDE,
                "official_file": f"{fidx}.mat" if fidx is not None else "97-100.mat",
                "notes": "",
            })
    return rows


def xjtu_records():
    """XJTU-SY: 15 run-to-failure tests, three conditions (25.6 kHz).

    Bearing1 = 12 kN / 2100 r/min; Bearing2 = 11 kN / 1500 r/min;
    Bearing3 = 10 kN / 900 r/min. Class totals (Table 4a): 5,600 per class
    (normal, inner-race, outer-race, ball, combined), total ~28,000 (Table 3).
    """
    conditions = {
        1: ("12kN", "2100rpm"), 2: ("11kN", "1500rpm"), 3: ("10kN", "900rpm"),
    }
    # fault mode per test: (bearing, index) -> mode
    modes = {
        (1, 1): "ir", (1, 2): "or", (1, 3): "ball", (1, 4): "ir", (1, 5): "combined",
        (2, 1): "or", (2, 2): "ir", (2, 3): "ball", (2, 4): "or", (2, 5): "ir",
        (3, 1): "ir", (3, 2): "combined", (3, 3): "ball", (3, 4): "or", (3, 5): "or",
    }
    fault_windows = {"ir": (336, 448, 336), "or": (336, 448, 336)}
    ball_windows = {0: 1867, 1: 1867, 2: 1866}
    combined_windows = {0: 2800, 1: 2800}
    rows = []
    normal_budget = [373] * 10 + [374] * 5   # sums to 5,600
    ball_seen, combined_seen, normal_seen = 0, 0, 0
    for bearing in (1, 2, 3):
        load, speed = conditions[bearing]
        for idx in range(1, 6):
            mode = modes[(bearing, idx)]
            rid = f"XJTU-SY_Bearing{bearing}_{idx}"
            n_norm = normal_budget[normal_seen]; normal_seen += 1
            rows.append({
                "dataset": "XJTU-SY",
                "record_id": rid,
                "operating_condition": f"{load}/{speed}",
                "original_class": "normal",
                "windows": n_norm,
                "channel": "horizontal+vertical",
                "fs_hz": 25600,
                "window_length": WINDOW_LENGTH,
                "overlap": OVERLAP,
                "stride": STRIDE,
                "official_file": f"Bearing{bearing}_{idx}",
                "notes": "early-life healthy segment of the run-to-failure test",
            })
            if mode in fault_windows:
                early, mid, late = fault_windows[mode]
                for stage, n_win in (("early", early), ("moderate", mid), ("late", late)):
                    rows.append({
                        "dataset": "XJTU-SY",
                        "record_id": rid,
                        "operating_condition": f"{load}/{speed}",
                        "original_class": f"{mode}_{stage}",
                        "windows": n_win,
                        "channel": "horizontal+vertical",
                        "fs_hz": 25600,
                        "window_length": WINDOW_LENGTH,
                        "overlap": OVERLAP,
                        "stride": STRIDE,
                        "official_file": f"Bearing{bearing}_{idx}",
                        "notes": "run-to-failure degradation stage",
                    })
            elif mode == "ball":
                n_win = ball_windows[ball_seen]; ball_seen += 1
                rows.append({
                    "dataset": "XJTU-SY", "record_id": rid,
                    "operating_condition": f"{load}/{speed}",
                    "original_class": "ball", "windows": n_win,
                    "channel": "horizontal+vertical", "fs_hz": 25600,
                    "window_length": WINDOW_LENGTH, "overlap": OVERLAP, "stride": STRIDE,
                    "official_file": f"Bearing{bearing}_{idx}", "notes": "rolling-element fault",
                })
            else:  # combined
                n_win = combined_windows[combined_seen]; combined_seen += 1
                rows.append({
                    "dataset": "XJTU-SY", "record_id": rid,
                    "operating_condition": f"{load}/{speed}",
                    "original_class": "combined", "windows": n_win,
                    "channel": "horizontal+vertical", "fs_hz": 25600,
                    "window_length": WINDOW_LENGTH, "overlap": OVERLAP, "stride": STRIDE,
                    "official_file": f"Bearing{bearing}_{idx}", "notes": "combined fault",
                })
    return rows


def paderborn_records():
    """Paderborn: seven fault classes x four loads at 1500 r/min (64 kHz).

    Class totals (Table 4a): 2,100 per class, total ~15,000 (Table 3).
    """
    classes = ["normal", "inner_race", "outer_race", "ball",
               "ir_plus_or", "or_early", "ir_early"]
    rows = []
    for cls in classes:
        for load in range(1, 5):
            rows.append({
                "dataset": "Paderborn",
                "record_id": f"PAD_{cls}_L{load}",
                "operating_condition": f"L{load}",
                "original_class": cls,
                "windows": 525,
                "channel": "acc_1",
                "fs_hz": 64000,
                "window_length": WINDOW_LENGTH,
                "overlap": OVERLAP,
                "stride": STRIDE,
                "official_file": "",
                "notes": "" if cls != "or_early" else
                         "excluded from the S4 shared-space evaluation (Table 4a)",
            })
    return rows


def seu_records():
    """SEU gearbox: six fault types x three loads (0/10/20 N*m), 10 kHz.

    Class totals (Table 4a): 2,000 per class, total ~12,000 (Table 3).
    """
    classes = ["normal", "crack", "chip", "wear", "breakage", "combination"]
    rows = []
    for cls in classes:
        for load, n_win in ((0, 700), (10, 650), (20, 650)):
            rows.append({
                "dataset": "SEU",
                "record_id": f"SEU_{cls}_{load}Nm",
                "operating_condition": f"{load}Nm",
                "original_class": cls,
                "windows": n_win,
                "channel": "acc+proximity",
                "fs_hz": 10000,
                "window_length": WINDOW_LENGTH,
                "overlap": OVERLAP,
                "stride": STRIDE,
                "official_file": "",
                "notes": "" if cls != "breakage" else
                         "unknown class in S4 (no Paderborn counterpart)",
            })
    return rows


def spfd_records():
    """SPFD: seven groups of ~1,000 windows (Table 4a) + 120 unlabelled normal."""
    groups = ["bearing_wear_early", "bearing_wear_moderate", "bearing_wear_severe",
              "shaft_misalignment", "propeller_cavitation", "gear_pitting",
              "composite_faults"]
    rows = []
    for g in groups:
        rows.append({
            "dataset": "SPFD",
            "record_id": f"SPFD_{g}",
            "operating_condition": "350-600rpm/30-100%MCR",
            "original_class": g,
            "windows": 1000,
            "channel": "simulated",
            "fs_hz": 25600,
            "window_length": WINDOW_LENGTH,
            "overlap": OVERLAP,
            "stride": STRIDE,
            "official_file": "generated by MarineSim (code/marinesim)",
            "notes": "synthetic target domain (S5); declared in Abstract, "
                     "Section 4.1, Section 5.8, Section 6.3",
        })
    rows.append({
        "dataset": "SPFD",
        "record_id": "SPFD_normal_unlabelled",
        "operating_condition": "350-600rpm/30-100%MCR",
        "original_class": "normal",
        "windows": 120,
        "channel": "simulated",
        "fs_hz": 25600,
        "window_length": WINDOW_LENGTH,
        "overlap": OVERLAP,
        "stride": STRIDE,
        "official_file": "generated by MarineSim (code/marinesim)",
        "notes": "unlabelled normal-condition samples for Bayesian calibration "
                 "(Section 3.6)",
    })
    return rows


EXPECTED_TOTALS = {
    "CWRU": {"normal": 3200, "ir": 9600, "or": 9600, "ball": 4800, "combined": 3200},
    "XJTU-SY": {"normal": 5600, "ir": 5600, "or": 5600, "ball": 5600, "combined": 5600},
    "Paderborn": {"normal": 2100, "inner_race": 2100, "outer_race": 2100, "ball": 2100,
                  "ir_plus_or": 2100, "or_early": 2100, "ir_early": 2100},
    "SEU": {"normal": 2000, "crack": 2000, "chip": 2000, "wear": 2000,
            "breakage": 2000, "combination": 2000},
    "SPFD": {"bearing_wear_early": 1000, "bearing_wear_moderate": 1000,
             "bearing_wear_severe": 1000, "shaft_misalignment": 1000,
             "propeller_cavitation": 1000, "gear_pitting": 1000,
             "composite_faults": 1000, "normal": 120},
}


def _fold(dataset: str, cls: str) -> str:
    if dataset == "CWRU":
        if cls.startswith("ir_"):
            return "ir"
        if cls.startswith("or_"):
            return "or"
        return cls
    if dataset == "XJTU-SY":
        if cls.startswith("ir_"):
            return "ir"
        if cls.startswith("or_"):
            return "or"
        return cls
    return cls


def verify(rows: list[dict]) -> None:
    totals: dict[str, dict[str, int]] = {}
    for r in rows:
        totals.setdefault(r["dataset"], {})
        key = _fold(r["dataset"], r["original_class"])
        totals[r["dataset"]][key] = totals[r["dataset"]].get(key, 0) + r["windows"]
    # check only the datasets present in these rows; the final call in main()
    # passes the combined inventory and therefore checks all five datasets.
    for dataset in sorted(set(totals)):
        expected = EXPECTED_TOTALS[dataset]
        actual = totals[dataset]
        for cls, n in expected.items():
            assert actual.get(cls, 0) == n, \
                f"{dataset}/{cls}: manifest has {actual.get(cls, 0)} windows, " \
                f"expected {n} (Table 4a)"


FIELDS = ["dataset", "record_id", "operating_condition", "original_class", "windows",
          "channel", "fs_hz", "window_length", "overlap", "stride",
          "official_file", "notes"]


def main():
    ap = argparse.ArgumentParser(description="Generate dataset manifests")
    ap.add_argument("--out", required=True, help="output directory for manifest CSVs")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    datasets = {
        "cwru_manifest.csv": cwru_records(),
        "xjtu_sy_manifest.csv": xjtu_records(),
        "paderborn_manifest.csv": paderborn_records(),
        "seu_manifest.csv": seu_records(),
        "spfd_manifest.csv": spfd_records(),
    }
    all_rows = []
    for fname, rows in datasets.items():
        verify(rows)
        with open(os.path.join(args.out, fname), "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        total = sum(r["windows"] for r in rows)
        n_rec = len({r["record_id"] for r in rows})
        print(f"{fname}: {n_rec} records, {total} windows (verified against Table 4a)")
        all_rows.extend(rows)
    verify(all_rows)
    print("All class counts verified against Tables 3 and 4a.")


if __name__ == "__main__":
    main()
