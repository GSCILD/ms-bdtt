"""Preprocessing package: windowing, dataset manifests and record-level splits."""
