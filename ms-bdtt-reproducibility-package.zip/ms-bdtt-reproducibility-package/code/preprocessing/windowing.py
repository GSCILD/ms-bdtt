"""Sliding-window segmentation and label mapping (Sections 4.1 and 4.2.1).

Window parameters used throughout the manuscript:
    window length 2048 samples, 50 % overlap, stride 1024 samples.

Partitions are created at the original-record (file) level BEFORE window
segmentation; windows originating from the same record never cross a partition
boundary (Section 4.4). The grouping variables are dataset x record file x
operating condition.
"""

from __future__ import annotations

import numpy as np

WINDOW_LENGTH = 2048
OVERLAP = 0.5
STRIDE = 1024


def sliding_windows(x: np.ndarray, window: int = WINDOW_LENGTH,
                    stride: int = STRIDE) -> np.ndarray:
    """Segment a 1-D signal into windows of `window` samples with the given stride.

    A 50 % overlap corresponds to stride = window // 2 = 1024.
    Returns an array of shape (n_windows, window).
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    if len(x) < window:
        return np.empty((0, window))
    n = 1 + (len(x) - window) // stride
    idx = np.arange(window)[None, :] + stride * np.arange(n)[:, None]
    return x[idx]


def n_windows_for_record(n_samples: int, window: int = WINDOW_LENGTH,
                         stride: int = STRIDE) -> int:
    """Number of windows obtained from a record of n_samples."""
    if n_samples < window:
        return 0
    return 1 + (n_samples - window) // stride


# ---------------------------------------------------------------------------
# Label mappings of Section 4.2.1 / Table 4a
# ---------------------------------------------------------------------------

# S3: CWRU -> XJTU-SY. Shared five-class space; severity-agnostic folding.
S3_SHARED_LABELS = ["normal", "inner_race", "outer_race", "rolling_element", "combined"]

S3_CWRU_MAP = {
    "normal": "normal",
    "ir_0.007": "inner_race", "ir_0.014": "inner_race", "ir_0.021": "inner_race",
    "or_0.007": "outer_race", "or_0.014": "outer_race", "or_0.021": "outer_race",
    "ball": "rolling_element",
    "combined": "combined",
}
S3_XJTU_MAP = {
    "normal": "normal",
    "ir_early": "inner_race", "ir_moderate": "inner_race", "ir_late": "inner_race",
    "or_early": "outer_race", "or_moderate": "outer_race", "or_late": "outer_race",
    "ball": "rolling_element",
    "combined": "combined",
}

# S4: Paderborn -> SEU. Partial-domain setting; SEU breakage is the unknown class.
S4_SHARED_LABELS = ["normal", "localised_defect", "distributed_defect",
                    "structural_fracture", "combined"]

S4_PADERBORN_MAP = {
    "normal": "normal",
    "inner_race": "localised_defect",
    "outer_race": "localised_defect",
    "ball": "localised_defect",
    "ir_plus_or": "combined",
    "or_early": None,   # excluded from the S4 shared-space evaluation (Table 4a)
    "ir_early": "localised_defect",
}
S4_SEU_MAP = {
    "normal": "normal",
    "crack": "distributed_defect",
    "chip": "distributed_defect",
    "wear": "distributed_defect",
    "breakage": "structural_fracture",   # unknown class: no Paderborn counterpart
    "combination": "combined",
}

# S5: four sources -> SPFD (unlabelled target).
S5_SOURCE_MAP = {
    "bearing_inner_race": "bearing_wear",
    "bearing_outer_race": "bearing_wear",
    "bearing_ball": "bearing_wear",
    "gear_crack": "gear_pitting",
    "gear_chip": "gear_pitting",
    "gear_wear": "gear_pitting",
}
S5_TARGET_ONLY_LABELS = ["shaft_misalignment", "propeller_cavitation", "composite_faults"]
S5_SHARED_LABELS = ["bearing_wear_early", "bearing_wear_moderate",
                    "bearing_wear_severe", "gear_pitting"]


def apply_label_map(original: str, mapping: dict) -> str | None:
    """Map an original dataset label onto a scenario's shared label space."""
    return mapping.get(original)


# ---------------------------------------------------------------------------
# Split integrity
# ---------------------------------------------------------------------------

def verify_record_level_split(records: list[dict], assignment: dict[str, str],
                              group_key=("dataset", "record_id", "operating_condition")) -> None:
    """Assert that no record is split across partitions.

    `records` is the record inventory; `assignment` maps record_id -> partition.
    Raises AssertionError if any record_id appears with more than one partition
    or is missing an assignment.
    """
    seen: dict[str, set[str]] = {}
    for rec in records:
        rid = rec["record_id"]
        part = assignment.get(rid)
        assert part in ("train", "validation", "test"), \
            f"record {rid} has no valid partition assignment (got {part!r})"
        seen.setdefault(rid, set()).add(part)
    for rid, parts in seen.items():
        assert len(parts) == 1, f"record {rid} spans partitions {parts}"
