# SPFD demonstration subset (seed 42)

This directory contains a small demonstration subset of the SPFD (synthetic ship
propulsion fault dataset) generated with MarineSim, produced by:

```bash
python code/marinesim/generate_spfd.py \
    --config code/marinesim/configs/spfd_config.yaml \
    --out data/spfd_demo --demo
```

## Contents

| File | Contents |
|---|---|
| `spfd_<group>.npz` | 100 demonstration windows (2048 samples, 25.6 kHz) per fault group; keys: `windows`, `fs`, `seed` |
| `spfd_normal_unlabelled.npz` | 100 unlabelled normal-condition demonstration windows (Bayesian-calibration input, Section 3.6) |
| `spfd_manifest.json` | dataset manifest (counts, seed, notes) |
| `spfd_window_index.csv` | window-level index (window_id, group, fault_type, window_index, seed) |

## Regenerating the full dataset

The full SPFD (approximately 1,000 windows per group, Table 4a) is regenerated
by the same script without `--demo`:

```bash
python code/marinesim/generate_spfd.py \
    --config code/marinesim/configs/spfd_config.yaml \
    --out <your-output-dir>
```

One simulation run (4 s of integration at a 1e-4 s step, Appendix B) takes
about 1 s on a modern CPU, so the full dataset is a one-time offline cost of a
few hours; the bridge and SPFD generation are offline preprocessing steps of
the pipeline (Section 5.7).

## Note

SPFD is synthetic (declared in the Abstract, Section 4.1, Section 5.8 and
Section 6.3 of the manuscript): it enables controlled and reproducible
evaluation under realistic marine conditions, but it does not substitute for
measurements from an operational vessel.
