# MS-BDTT Reproducibility Package

**Marine-power-System Bayesian Digital Twin Transfer for Cross-Domain Fault Diagnosis via Continuous Domain Interpolation**

Dong Liu, Jie Liu

Version-controlled data and code deposit accompanying the manuscript.
DOI (to be replaced before submission): **Zenodo: 10.5281/zenodo.XXXXXXX**
Version: 1.0 · Seed: 42 · Environment: PyTorch 2.0, CUDA 11.8

---

## 1. What this deposit contains

This package is the public data deposit referenced in the *Data availability* statement of the manuscript.
It contains everything needed to reproduce every table and figure in the paper:

| Component | Location | Corresponding statement in the manuscript |
|---|---|---|
| Four public dataset manifests (CWRU, XJTU-SY, Paderborn, SEU) | `data/manifests/` | "the dataset manifests … are deposited" |
| SPFD manifest | `data/manifests/spfd_manifest.csv` | "MarineSim inputs, the SPFD generation scripts" |
| Record-level split manifests for scenarios S1–S5 | `data/splits/` | "the preprocessing and split scripts" |
| MarineSim simulator kernel and configuration (Table A.1 parameters) | `code/marinesim/` | "MarineSim inputs" |
| SPFD generation script | `code/marinesim/generate_spfd.py` | "the SPFD generation scripts" |
| Preprocessing / windowing script (2048 / 50 % / 1024) | `code/preprocessing/windowing.py` | "the preprocessing … scripts" |
| Split-generation script (seed 42, record level) | `code/preprocessing/make_splits.py` | "the preprocessing and split scripts" |
| Manifest-generation script | `code/preprocessing/make_manifests.py` | "the dataset manifests" |
| MS-BDTT training code (model, attention, particle filter, losses, demand map) | `code/ms_bdtt/` | "the trained model configurations" |
| Trained model configuration (all hyperparameters, Table D.1 values) | `configs/ms_bdtt_trained_config.yaml` | "the trained model configurations" |
| Software environment (PyTorch 2.0, CUDA 11.8) | `code/requirements.txt`, `code/environment.yml` | "the software environment (PyTorch 2.0, CUDA 11.8)" |
| Exact random seeds (42) | `seeds.json` | "the exact random seeds (42)" |
| Single version-controlled results file | `code/experiments/results_all.json` | "regenerated from a single version-controlled results file" |
| Machine-readable tables (Tables 3, 4a, 5–10, C.1, D.1, E.1) | `results/tables/` | "the scripts used to regenerate every table" |
| Run-level predictions (per method, per seed, per scenario) | `results/run_level_predictions/` | "the run-level predictions" |
| Figure-regeneration script and rendered figures (Figures 2, 5, 6, 7, 8, 9, 10) | `code/experiments/regenerate_figures.py`, `results/figures/` | "the scripts used to regenerate every … figure" |
| Small SPFD demonstration subset (seed 42) | `data/spfd_demo/` | — |

The four public datasets themselves (CWRU, XJTU-SY, Paderborn, SEU) are **not** redistributed here; they are
available from the repositories cited in Section 4.1 of the manuscript. See `data/public_datasets.md` for the
exact sources, versions and access notes. This deposit provides the dataset **manifests** (class counts,
channel selection, window parameters, exclusions) and the **split manifests** for those datasets.

## 2. Quick start

```bash
# 1. Environment (Python 3.10+, PyTorch 2.0, CUDA 11.8)
cd code
conda env create -f environment.yml      # or: pip install -r requirements.txt
conda activate ms-bdtt

# 2. Regenerate the dataset manifests (verifies class counts against the manuscript)
python preprocessing/make_manifests.py --out ../data/manifests

# 3. Regenerate the record-level splits for all five scenarios (seed 42)
python preprocessing/make_splits.py --out ../data/splits

# 4. Generate the SPFD demonstration subset with MarineSim (seed 42)
python marinesim/generate_spfd.py \
    --config marinesim/configs/spfd_config.yaml \
    --out ../data/spfd_demo --demo

# 5. Regenerate every machine-readable table from the single results file
python experiments/regenerate_tables.py \
    --results experiments/results_all.json --out ../results/tables \
    --run-level-out ../results/run_level_predictions

# 6. Regenerate every figure
python experiments/regenerate_figures.py \
    --results experiments/results_all.json --out ../results/figures

# 7. Train MS-BDTT from scratch (single scenario example; see code/README.md)
python ms_bdtt/train.py --scenario S5 --config ../configs/ms_bdtt_trained_config.yaml
```

All scripts are deterministic under the fixed seed (42) recorded in `seeds.json`; re-running them reproduces
the shipped files bit-for-bit.

## 3. Reproducibility conventions

* **Seed.** All randomness (initialisation, shuffling, noise realisations, split assignment) derives from the
  single seed 42 (`seeds.json`), applied as `torch.manual_seed(42)`, `torch.cuda.manual_seed_all(42)`,
  `numpy.random.seed(42)`. Independent repetitions of each experiment use seeds 42, 43, 44 (three runs).
* **Splits.** Train/validation/test partitions are created at the original-record (file) level *before*
  window segmentation; windows from the same record never cross a partition boundary. Grouping variables:
  dataset × record file × operating condition. The split manifests for every scenario are in `data/splits/`.
* **Label spaces.** Scenario label mappings and before/after class counts follow Section 4.2.1 and Table 4a
  of the manuscript; the manifests in `data/manifests/` reproduce those counts exactly (verified by
  `make_manifests.py` assertions).
* **Results.** Every number in the paper is regenerated from the single file
  `code/experiments/results_all.json`; `regenerate_tables.py` and `regenerate_figures.py` emit the shipped
  CSVs and PNGs from that one source, with automated consistency checks (means, differences, cumulative
  effects) that fail loudly if any aggregate disagrees with the per-scenario values.
* **Measured vs. fitted evidence.** Where the manuscript distinguishes measured anchors from fitted visual
  aids (Figures 5(b) and 10), the shipped figure data keeps the same distinction: measured points are stored
  in `results_all.json` under `measured`, fitted points are computed by the figure script from the anchors.

## 4. File inventory

```
ms-bdtt-reproducibility-package/
├── README.md                        this file
├── LICENSE                          CC-BY-4.0 (data/docs) + MIT (code)
├── CITATION.cff                     citation metadata
├── seeds.json                       exact random seeds
├── data/
│   ├── public_datasets.md           the four public datasets: sources, versions, access notes
│   ├── manifests/                   cwru / xjtu_sy / paderborn / seu / spfd manifests (CSV)
│   ├── splits/                      S1–S5 record-level split manifests (JSON)
│   └── spfd_demo/                   small seed-42 SPFD demonstration subset (NPZ)
├── code/
│   ├── README.md                    code documentation and run order
│   ├── requirements.txt             pip environment
│   ├── environment.yml              conda environment (PyTorch 2.0, CUDA 11.8)
│   ├── marinesim/                   rotordynamic simulator, sensor noise model, SPFD generator
│   ├── preprocessing/               windowing, manifest and split generators
│   ├── ms_bdtt/                     model, attention, particle filter, losses, demand map, trainer
│   └── experiments/                 single results file + table/figure regeneration scripts
├── configs/
│   └── ms_bdtt_trained_config.yaml  trained model configuration (all hyperparameters)
└── results/
    ├── tables/                      machine-readable versions of every paper table
    ├── run_level_predictions/       per-run predictions (method × seed × scenario)
    └── figures/                     rendered figures (PNG) + plotted input data (CSV)
```

## 5. Data availability of the four public datasets

| Dataset | Source (Section 4.1 citation) | Repository |
|---|---|---|
| CWRU bearing data | [36] Smith & Randall (2015) | Case Western Reserve University Bearing Data Center |
| XJTU-SY run-to-failure | [37] Xi'an Jiaotong University & Changxing Sumyoung (2018) | XJTU-SY rolling-element bearing dataset |
| Paderborn bearing data | [38] Lessmeier et al. (2016) | PHM Society / Paderborn University benchmark |
| SEU gearbox data | [39] Shao et al. (2018) | Southeast University gearbox dataset |

Exact repository URLs, versions, channel selections, window parameters and exclusions are documented in
`data/public_datasets.md` and encoded in the manifests.

## 6. License

* Code: MIT License (see `LICENSE`).
* Data, manifests, tables, figures and documentation: Creative Commons Attribution 4.0 International
  (CC-BY-4.0).

## 7. Citation

If you use this deposit, please cite the manuscript (see `CITATION.cff`):

> Dong Liu, Jie Liu. *Digital Twin Transfer for Marine Power Fault Diagnosis via Continuous Domain
> Interpolation (MS-BDTT).* Zenodo. https://doi.org/10.5281/zenodo.XXXXXXX

## 8. Contact

Corresponding author: Dong Liu (first author, conceptualisation, methodology, software).
For questions about the simulator configuration, the split protocol or the results file, open an issue in the
version-controlled repository or contact the corresponding author.
